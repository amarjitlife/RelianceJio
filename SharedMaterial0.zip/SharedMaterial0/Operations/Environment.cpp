
_________________________________________________________________

UBUNTU LINUX ENVIRONMENT PREPARATION
_________________________________________________________________


_________________________________________________________________

Follow Following Tutorial 
_________________________________________________________________

	1. Download Following Softwares
			Oracle VirtualBox For Windows Machine
			Link : https://www.virtualbox.org/wiki/Downloads

			>>>> NOTE :
				First Install Ubuntu Desktop 22.04 64 Bit In VirtualBox Irrespective Laptop RAM Size

				If Laptop RAM Is 06 GB +
					Than Allocate RAM In VirtualBox 2 GB

				If Laptop RAM Is 04 GB 
					Than Allocate RAM In VirtualBox 1.5 GB

			Machine With 4GB+ RAM
				Install Either Ubuntu Server Or Ubuntu Desktop 
				
				Ubuntu 22.04 Desktop 64 Bit ISO File
				Link : https://ubuntu.com/download/desktop/thank-you?version=22.04&architecture=amd64

				Allocate RAM In VirtualBox
					1.5 GB To 2 GB

			>>>> NOTE :

			In Case Ubuntu Desktop 22.04 64 Bit IS TOO SLOW IN 4 GB RAM MACHINE
			
				Install Ubuntu Server 22.04 64 Bit In VirtualBox

				If Laptop RAM Is 04 GB 
					Than Allocate RAM In VirtualBox 1.5 GB

				Machine Having 4GB RAM
					Ubuntu 22.04 Server 64 Bits ISO File Having 1.4 Size GB
					Link : https://ubuntu.com/download/server
						Download File : ubuntu-22.04-live-server-amd64.iso


	2. Install VirtualBox
		Oracle VirtualBox For Windows Machine
		Link : https://www.virtualbox.org/wiki/Downloads

	3. Install Ubuntu 22.04 64 Bit Server Or Desktop 

	 	Ubuntu Server 22.04 64 Bit 
			Link : https://getlabsdone.com/how-to-install-ubuntu-22-04-lts-server-in-virtualbox/

	 	Ubuntu Desktop 22.04 64 Bit 
			Link : https://www.thecoderworld.com/install-ubuntu-on-virtualbox/
			Youtube Video Link : https://www.youtube.com/watch?v=zHwFtyxJsog
			Youtube Video Link : https://www.youtube.com/watch?v=v1JVqd8M3Yc


	4. Update Your Status In Following Google Sheet

		Link: https://tinyurl.com/2p9mzuw6

	5. Check g++ And gcc Compilers Are Installed

		# Run Following Commands In Terminal

			g++ --version
			gcc --version

		In Case It's Installed 
			i.e. Than g++ and/or gcc Command Not Found Error

	6. Installing g++ And gcc Compilers

		# Run Following Commands In Terminal

			sudo apt update
			sudo apt install build-essential
			sudo apt install cmake

	7. Installing Source Code Editors In Ubuntu Desktop

		# INSTALLING VIM EDITOR
			sudo apt install vim

		# INSTALLING SUBLIME TEXT
			sudo snap install sublime-text --classic

		# INSTALLING VISUAL STUDIO CODE
			sudo snap install code --classic

	7. Create Hello.cpp File With Following Code Using Any Editor

		#include <iostream>

		int main() {
			std::cout << "Hello World!";
		}

		Save Hello.cpp In Directory YOUR_CODE_PATH/RelianceJio/Code

	8. Compile Hello.cpp With Following Command

		cd YOUR_CODE_PATH/RelianceJio/Code

		g++ Hello.cpp -o hello

	9. Run Hello.cpp with Following Command

		cd YOUR_CODE_PATH/RelianceJio/Code
		./hello

_________________________________________________________________
