______________________________________________________

Linux Commands
______________________________________________________

1. To Change Directory
	Use cd Command

		cd Documents

2. To Make Directory
	mkdir LearnLinux
	cd LearnLinux
	mkdir HindiCinema
	cd HindiCinema

3. To Check Present/Current Working Directory
	pwd

	Change Present/Current Directory To Parent Directoy
		cd ..
	
	pwd
	cd ..
	pwd
	cd ..
	pwd

4. List Content Of Directory
		ls

	To Give Detailed Listing Use Following Command
		ls -l 

	To List All The Files Use Following Command
		Will Show File Names Starting With . Also
			ls -a -l 
			ls -al


