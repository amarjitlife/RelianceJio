
_____________________________________________________________________________
MEETING LINK DOCUMENT

Join from the meeting link
https://nanocellnetworks-training.webex.com/nanocellnetworks-training/j.php?MTID=m0b5d22cacbdf0b09131a5a2c9409e3b8
https://nanocellnetworks-training.webex.com/nanocellnetworks-training/j.php?MTID=m0b5d22cacbdf0b09131a5a2c9409e3b8
https://nanocellnetworks-training.webex.com/nanocellnetworks-training/j.php?MTID=m0b5d22cacbdf0b09131a5a2c9409e3b8


Meeting number:
2518 430 1768

Access code: 
2518 430 1768

_____________________________________________________________________________
// BATCH DETAILS DOCUMENT

https://tinyurl.com/2p9mzuw6
https://tinyurl.com/2p9mzuw6
https://tinyurl.com/2p9mzuw6

https://docs.google.com/spreadsheets/d/1bx-I440LVjJd-NS7CfwOe7zfA91Lbof7ktYGruXLZLw/edit?usp=sharing
https://docs.google.com/spreadsheets/d/1bx-I440LVjJd-NS7CfwOe7zfA91Lbof7ktYGruXLZLw/edit?usp=sharing
https://docs.google.com/spreadsheets/d/1bx-I440LVjJd-NS7CfwOe7zfA91Lbof7ktYGruXLZLw/edit?usp=sharing

_____________________________________________________________________________
_____________________________________________________________________________
_____________________________________________________________________________
_____________________________________________________________________________
_____________________________________________________________________________


