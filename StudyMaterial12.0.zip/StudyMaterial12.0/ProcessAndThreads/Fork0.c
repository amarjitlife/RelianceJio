#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 

int main() { 
	/* fork a process */
	fork(); 
	// The child and parent will execute 
	// every line of code after the fork (each separately)
	printf("Hello World!...\n"); 
	return 0; 
} 

