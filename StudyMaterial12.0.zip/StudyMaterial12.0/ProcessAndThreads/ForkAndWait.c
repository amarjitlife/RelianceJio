
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {

	pid_t childPID = fork();

	if ( childPID < 0 ) {
		printf("Forking Failed!...\n");
		exit( EXIT_FAILURE );
	} else if ( childPID == 0 ) {
		printf("Child Process PID: %u PPID: %u\n", getpid(), getppid());
		getchar();
		// return 1;
	} else {
		// wait Will Make Parent To Wait For Child To Complete
		wait( NULL );
		printf("Parent Process PID: %u PPID: %u\n", getpid(), getppid());
		printf("\tChild Process Complete Execution...\n");
		getchar();
	}
}
