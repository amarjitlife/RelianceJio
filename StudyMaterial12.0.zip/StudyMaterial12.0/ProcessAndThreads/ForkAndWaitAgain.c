
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
	printf("Before Forking PID: %u PPID: %u\n", getpid(), getppid() );
	pid_t childPID = fork();
	printf("After Forking Return Value: %d\n", childPID);

	if ( childPID < 0 ) {
		printf("Forking Failed!...\n");
	} 

	if ( childPID == 0 ) {
		printf("Child Process PID: %u PPID: %u\n", getpid(), getppid());
		// return 1;
		exit( 0 );
	} 

	printf("Parent Process Waiting For Child To Complete...");	
	// wait Will Make Parent To Wait For Child To Complete
	wait( NULL );
	printf("Process PID: %u PPID: %u\n", getpid(), getppid());
	printf("\tChild Process Completed...\n");
	getchar();
}


