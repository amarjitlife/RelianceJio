#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int staticData = 111;

int main( int argc, char *argv ) {	
	int stackData = 222;
	char processType[20] = "";

	// Forking Process : Creating One More Process
	int childPID = fork(); 
	switch( childPID ) {
		case -1:
			printf("\nForking Error Happened!...");
			exit( 0 );
		case 0:
			stackData = staticData * 3;
			stackData = staticData * 3;
		default:
			sleep( 3 );
			break;
	}

	if ( childPID == 0 ) 
		strcpy(processType, "Child Process :");
	else 
		strcpy(processType, "Parent Process:");
	
	printf("%s  PID = %ld staticData = %d, stackData = %d \n", processType,
		(long)getpid(), staticData, stackData );

	char ch = getchar();
	exit( EXIT_SUCCESS );
}
// Parent Process:  PID = 8068 staticData = 111, stackData = 222 
// Child Process :  PID = 8069 staticData = 111, stackData = 333

