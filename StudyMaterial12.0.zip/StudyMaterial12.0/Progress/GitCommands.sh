       cd Documents
 2079  pwd
 2080  git clone https://github.com/amarjitlife/LearnGit.git
 2082  git --version
 2083  ls
 2084  cd LearnGit/
 2086  ls
 2087  ls -l
 2088  cat README.md 
 2095  git status
 2096  git config --list
 2097  git log
 2101  touch factorial.c
 2102  ls -l
 2103  vim factorial.c 
 2104  git status
 2105  git add factorial.c 
 2106  git status
 2107  git commit
 2108  git config --local user.email "amarjitlife@gmail.com"
 2109  git config --local user.name "Amarjit Singh"
 2110  git config --list
 2113  git config --local core.editor "vim"
 2114  git config --list
 2116  vim --version
 2121  git status
 2115  git commit
 2118  git log
 2128  vim factorial.c 
 2129  cat factorial.c 
 2132  git status
 2134  ls -l
 2135  git status
 2136  git diff
 2137  git add factorial.c 
 2138  git status
 2139  git diff
 2140  git diff --cached
 2141  git status
 2142  git diff --cached
 2143  git commit
 2144  git status
 2145  git log

____________________________________________________________

 2001  cd Documents/
 2002  ls
 2003  cd LearnGit/
 2004  clear
 2005  git log
 2006  git help config
 2007  clear
 2008  git status
 2009  git log
 2010  clear
 2011  git status
 2012  ls
 2013  touch sum.c
 2014  git status
 2015  git diff
 2016  git add sum.c
 2017  git status
 2018  git diff
 2019  vim sum.c
 2020  git status
 2021  git diff
 2022  git add sum.c 
 2023  git status
 2024  git diff
 2025  git diff --cached
 2026  git diff --staged
 2027  git commit
 2028  git status
 2029  git log

____________________________________________________________


 2033  mkdir Maths
 2034  ls
 2035  git status
 2036  git mv factorial.c Maths/
 2037  git mv sum.c Maths/
 2038  git status
 2039  ls
 2040  tree             //NOTE:  use ls command instead
 2041  git commit
 2042  git status
 2043  git log

____________________________________________________________

 2072  touch someUselessFile.c
 2073  vim someUselessFile.c 
 2074  git status
 2075  git add someUselessFile.c 
 2076  git status
 2077  git diff
 2078  git diff --staged
 2079  git diff --cached
 2080  git status
 2081  vim someUselessFile.c 
 2082  git status
 2083  git diff
 2084  git diff --staged
 2085  git status
 2086  git add someUselessFile.c 
 2087  git status
 2088  git diff
 2089  git diff --staged
 2090  vim someUselessFile.c 
 2091  git status
 2092  git diff
 2093  git diff --staged
 2094  git status
 2095  git add someUselessFile.c 
 2096  git status
 2097  git diff --cached
 2098  git commit
 2099  git status
 2100  git log
 2101  git status
 2102  ls
 2103  git rm someUselessFile.c 
 2104  git status
 2105  ls
 2106  git diff
 2107  git diff --staged
 2108  git commit
 2109  git status
 2110  git diff
 2111  git diff --staged
 2112  git log
 2113  git log --patch

____________________________________________________________

 2116  git log -2
 2117  git log -4
 2118  git log -1
 2119  git log -3
 2120  git log -1 --patch
 2121  git log --patch -2
 2122  git log -s
 2123  git log 
 2125  git log --pretty=oneline

____________________________________________________________

 2130  cd Maths/
 2131  ls
 2132  pwd
 2133  c
 2134  clear
 2135  ls
 2136  vim factorial.c 
 2137  vim sum.c 
 2138  cd ..
 2139  clear
 2140  ls
 2141  git status
 2142  git diff
 2143  cd Maths/
 2144  vim factorial.c 
 2145  cd ..
 2146  git status
 2147  git diff
 2148  git status
 2149  git add Maths/factorial.c 
 2150  git add Maths/sum.c 
 2151  git status
 2152  git diff
 2153  git diff --staged
 2154  git commit
 2155  git status
 2156  git log
 2157  git log --patch -1

____________________________________________________________

 2168  touch UselessAgain.c
 2169  vim UselessAgain.c 
 2170  git status
 2171  git diff
 2172  git add UselessAgain.c 
 2173  git status
 2174  git diff
 2175  git diff --staged
 2176  git restore --staged UselessAgain.c
 2177  git diff --staged
 2178  git diff
 2179  git status
 2180  ls
 2181  rm UselessAgain.c 
 2182  clear
 2183  ls
 2184  cd Maths/
 2185  ls
 2186  vim sum.c 
 2187  git status
 2188  cd ..
 2189  clear
 2190  ls
 2191  git status
 2192  git diff
 2193  git add sum.c
 2194  git add Maths/sum.c
 2195  git status
 2196  git diff
 2197  git diff --staged
 2198  git restore --staged Maths/sum.c
 2199  git diff --staged
 2200  git status
 2201  git diff
 2202  git restore Maths/sum.c
 2203  git status
 2204  git diff
 2205  clear
 2206  ls
 2207  git remote
 2208  git status
 2209  git config --list
 2210  git tag
 2211  git log
 2212  git log --pretty=oneline
 2213  git log 
 2214  git status
 2215  git tag -a v0.1 -m "Version 0.1"
 2216  git tag
 2217  git log
 2218  git show v0.1
 2219  git tag
 2220  git tag -l

____________________________________________________________

 2224  git status
 2225  git branch Developer
 2226  git status
 2227  git branch
 2228  git checkout Developer
 2229  git branch
 2230  git status
 2231  ls
 2232  mkdir Stats
 2233  cd Stats/
 2234  touch Average.c
 2235  touch Probability.c
 2236  git status
 2237  cd ..
 2238  git status
 2239  cd Stats/
 2240  ls
 2241  vim Average.c 
 2242  vim Probability.c 
 2243  git status
 2244  cd ..
 2245  git status
 2246  git add Stats/.
 2247  git status 
 2248  git commit
 2249  git status
 2250  git log
 2251  git branch
 2252  git status
 2253  git checkout main
 2254  git status
 2255  git log

____________________________________________________________

 2266  git status
 2267  cd .git/
 2268  ls
 2269  cat HEAD 
 2270  cat refs/heads/main 
 2271  cat refs/heads/Developer 
 2272  git branch
 2273  cd ..
 2274  clear
 2275  ls
 2276  tree
 2277  git status
 2278  git branch
 2279  git checkout Developer
 2280  git branch
 2281  git status
 2282  ls
 2283  tree
 2284  ls -R
 2285  git branch
 2286  git chekout main
 2287  git checkout main
 2288  git branch
 2289  git status
 2290  ls -R
 2291  vim Maths/factorial.c 
 2292  vim Maths/sum.c 
 2293  git status
 2294  git diff
 2295  git status
 2296  git branch
 2297  git add Maths/.
 2298  git status
 2299  git diff --staged
 2300  git status
 2301  git commit
 2302  git status
 2303  git branch
 2304  git log
 2305  git checkout Developer
 2306  git log
 2307  git checkout main
 2308  git branch
 2309  git status
 2310  vim Maths/factorial.c 
 2311  vim Maths/sum.c 
 2312  git status
 2313  git diff
 2314  git status
 2315  git add Maths/sum.c 
 2316  git status
 2317  git diff
 2318  git diff --staged
 2319  git status
 2320  git branch
 2321  git commit
 2322  git status
 2323  git log
 2324  git checkout Developer
 2325  git status
 2326  git branch
 2327  git log
 2328  git checkout main
 2329  git log

____________________________________________________________

 2324  git checkout Developer
 2325  git status
 2326  git branch
 2327  git log
 2328  git checkout main
 2329  git log
 2330  history
 2331  git log --graph
 2332  clear
 2333  git log --oneline
 2335  clear
 2336  ls
 2337  git log --oneline --decorate
 2338  clear
 2339  ls
 2340  git status
 2341  git branch
 2342  git log
 2343  git status
 2344  git branch
 2345  git merge Developer
 2346  tree
 2347  ls -R
 2348  git log
 2350  git log
 2351  git log --graph
____________________________________________________________

 
 2355  git status
 2356  git branch
 2357  git checkout Developer
 2358  git branch
 2359  git branch -d Developer
 2360  git status
 2361  git checkout main
 2362  git branch
 2363  git status
 2364  git branch -d Developer
 2365  git branch
 2366  git status

____________________________________________________________

 2377  git branch
 2378  tree
 2379  ls -R
 2380  mkdir Calculus
 2381  clear
 2382  ls
 2383  cd Calculus/
 2384  ls
 2385  touch Limits.c
 2386  touch Derivative.cpp
 2387  vim Limits.c 
 2388  vim Derivative.cpp 
 2389  git status
 2390  git add .
 2391  clear
 2392  ls
 2393  git status
 2394  git branch FeatureCalculus
 2395  git branch
 2396  git checkout FeatureCalculus 
 2397  git branch
 2398  git status
 2399  git diff
 2400  git diff --staged
 2401  cd ..
 2402  vim Calculus/Limits.c 
 2403  git diff --staged
 2404  git status
 2405  git diff
 2406  git add Calculus/Limits.c 
 2407  git statu
 2408  git status
 2409  git commit
 2410  git log
 2411  git log --graph
 2412  vim Calculus/Derivative.cpp 
 2413  vim Calculus/Integration.cpp
 2414  git status
 2415  git diff
 2416  git add Calculus/Integration.cpp 
 2417  git status
 2418  git diff
 2419  git diff --staged
 2420  git status
 2421  git add Calculus/Derivative.cpp 
 2422  git status
 2423  git diff
 2424  git diff --staged
 2425  git status
 2426  git branch
 2427  git commit
 2428  git status
 2429  git log
 2430  git branch
 2431  git branch FeatureCalculusExperiment
 2432  git branch
 2433  git checkout FeatureCalculusExperiment 
 2434  git log --graph
 2435  clear
 2436  ls
 2437  cd Calculus/
 2438  ls
 2439  vim Integration.cpp 
 2440  git status
 2441  git diff
 2442  git status
 2443  git add Integration.cpp 
 2444  git status
 2445  git commit
 2446  git log
 2447  clear
 2448  ls
 2449  cd ...
 2450  cd ..
 2451  clear
 2452  ls
 2453  git branch
 2454  git checkout Developer 
 2455  git branch
 2456  git status
 2457  git merge FeatureCalculus
 2458  git log
 2459  clear
 2460  ls
 2461  git branch
 2462  git branch --merged
 2463  git branch -v
 2464  git branch --verbose
 2465  git branch
 2466  git branch -v
 2467  git branch --merged
 2468  git branch --no-merged
 2469  clear

____________________________________________________________


 2003  cd LearnGit/
 2007  git branch
 2008  git checkout main
       git pull
 2009  git push origin main

1. Generate Your Personal GitHub Token
    https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token

2. Use Generated Personal Token In Place Of Your Password

____________________________________________________________


At GitHub Server
    In LearnGit Repository
        
        Do Following At GitHub Server Side
        1. Edit Average.c File With Following Two Lines

            int average(int x, int y);
            int average(int x, int y, int z);

        2. Commit Changes 


In Your Local Machine

       cd LearnGit
 2016  git branch
       git checkout main
 2017  git pull
 2018  git log

    Check Changes Done Repository@Remote Machine  
        Came To Repository@Local Machine

    Do Your Local Changes @ Local Machine
    git commit

    git pull
    git push origin main

____________________________________________________________


 2020  git branch
 2021  git checkout Developer
 2022  git push origin Developer
 2023  git branch

____________________________________________________________


 Do Changes In Local Machine

 2031  cd Calculus/
 2032  ls
 2033  vim Limits.c 
 2034  vim Derivative.cpp 
 2035  vim Limits.c 
 2036  git branch
 2037  git status
 2038  git diff
 2039  git add Limits.c Derivative.cpp 
 2040  cd ..
 2041  clear
 2042  ls
 2043  git status
 2044  git commit


____________________________________________________________

1. Changes Done By Programmer 01 @ Local Repository 01

 2031  cd Calculus/
 2032  ls
 2033  vim Limits.c 
 2034  vim Derivative.cpp 
 2035  vim Limits.c 
 2036  git branch
 2037  git status
 2038  git diff
 2039  git add Limits.c Derivative.cpp 
 2040  cd ..
 2043  git status
 2044  git commit
 2045  git log
 2048  git log -1 -p

2. Simualte Local Changes Done By Programmer 02 @ Local Repository 02
        In Derivative.cpp Change Same Lines
   and Push To Remote Repository

 2003  mkdir AnotherProgrammer
 2004  cd AnotherProgrammer/
 2006  git clone https://github.com/amarjitlife/LearnGit.git
 2007  git branch
 2008  cd LearnGit/
 2009  git branch
 2014  git branch -a
 2015  git branch
 2016  git checkout Developer
 2017  git branch
 2018  git log
 2019  ls
 2020  vim Calculus/Derivative.cpp 
 2021  vim Calculus/Integration.cpp 
 2022  git status
 2023  git diff
 2024  git add Calculus/Integration.cpp Calculus/Derivative.cpp 
 2025  git status
 2026  ls
 2027  git config --list
 2031  git config --local user.name "Mr. Singh"
 2032  git config --local user.email "amarjitmca04@gmail.com"
 2033  git config --list
 2036  git config --local core.editor vim
 2037  git config --list
 2034  git status
 2038  git commit
 2039  git log
 2040  git branch
 2041  git log -1
 2042  git push origin Developer


3. Fetch Changes Done By Another Programmer From Remote Machine

 2049  git branch
 2060  git fetch --all

4. Merge To Your Local Repository Or Programmer 01

 2061  git branch
 2062  git branch -r
       git checkout Developer
 2063  git merge origin/Developer
 
5. Merge Conflict Happened -> Resolve Conflicts Manually

 2064  vim Calculus/Derivative.cpp 
 2065  git commit
 2066  git status
 2067  git add Calculus/Derivative.cpp 
 2068  git status
 2069  git commit
 2070  git log

____________________________________________________________

____________________________________________________________

____________________________________________________________

