#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h> 

int main() { 
	if ( fork() == 0 ) 
		if ( fork() )
			printf("Hello World!...\n"); 
	exit( 0 );
} 
