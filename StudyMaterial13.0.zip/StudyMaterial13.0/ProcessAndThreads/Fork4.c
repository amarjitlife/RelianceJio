
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main() {
	pid_t childPID;
	char *message;
	int n;

	printf("Forking Process...\n");
	childPID = fork();

	switch( childPID ) {
		case -1:
			perror("Fork Failed!...");
			exit( 1 );
		case 0:
			message = "This Is The Child Process";
			n = 5;
			break;
		default:
			message = "This Is The Parent Process";
			n = 3;
			break;
	}

	for ( ; n > 0 ; n-- ) {
		puts(message);
		sleep( 1 );
	}
	exit( 0 );
}
