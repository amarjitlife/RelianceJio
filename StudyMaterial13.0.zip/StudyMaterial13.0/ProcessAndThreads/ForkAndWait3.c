#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
	pid_t childPID;
	char *message;
	int n;
	int exit_code;

	printf("Forking Process...\n");
	childPID = fork();
	switch( childPID ) {
		case -1: 
			printf("Forking Failed!\n"); exit( EXIT_FAILURE );
		case 0: // Code Runs Child Process
			message = "This Is The Child Process";
			n = 5;
			exit_code = 37;
			getchar();
			break;
		default: // Code Runs Parent Process
			message = "This Is Parent Process";
			n = 3;
			exit_code = 0;
			break;
	}

	for ( ; n > 0 ; n-- ) {
		puts( message );
		sleep( 1 );
	}

	if ( childPID ) { // Code Running Parent Process
		int statusValue;
		pid_t childPID;
	
		// wait Does Parent Will Wait For Child To Complete
		childPID = wait( &statusValue );

		if( WIFEXITED( statusValue ) ) 
			printf("Child Finished Successfully PID = %u\n", childPID);
		else 
			printf("Child Terminated Abnormally PID = %u\n", childPID);

		printf("Child Process Exit Code: %d\n", WEXITSTATUS( statusValue ) );
	}

	printf("Process PID = %u PPID = %u\n", getpid(), getppid() ) ;		
	exit ( exit_code );
}
