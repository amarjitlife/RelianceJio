#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main( int argc, char **argv ) {	
	char message[501] = "Good Morning!";
	char receivedMessage[50];

	printf("\nArgc: %d", argc);
	for( int i = 0 ; i < argc ; i++ ) 
		printf("\nArgv[%d] : %s", i, argv[i] );

	printf("\nOriginal Message: %s", message );

	for( int i = 1 ; i < argc ; i++ ) { 
		strcat( message, " " );
		strcat( message, argv[i] );
	}

	printf("\nRecieved Message: %s\n", message );
	return 0;
}

/* Compilation And Running
gcc MyGreetings.c -o greetings
./greetings Amarjit
./greetings Amarjit Rohit Rohan
*/
