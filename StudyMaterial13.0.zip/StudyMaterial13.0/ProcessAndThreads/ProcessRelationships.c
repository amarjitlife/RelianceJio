
#include <stdlib.h> 
#include <stdio.h>

int main() {
	printf("Running ps with system\n"); 

	// system("ps ax");
	system("ps -ef");

	printf("Running ps -ef Command. Done.\n");

	exit(0);
}
