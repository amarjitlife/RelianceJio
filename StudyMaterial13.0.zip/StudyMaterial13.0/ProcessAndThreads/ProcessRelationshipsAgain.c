
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	char ch;

	printf("Running Command : ps -ef ");

	// system("ps -ef");

	execlp("ps", "ps", "ef", NULL);

	printf( " Compeleted Creating Process: ps -ef" );


	while( ( ch = getchar() ) != EOF ) {
		// putchar( toupper( ch ));
	}

	exit( 0 );
}

