#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

static int alarmFired = 0;

void signalHandlerFirst(int sig) {
    printf("Got Signal SIGALRM :  %d\n", sig);
    alarmFired = 1;
}

int main() {
	pid_t childPID;
	char *processName;
	int exit_code;

	printf("Forking Process...\n");
	childPID = fork();
	switch( childPID ) {
		case -1: 
			printf("Forking Failed!\n"); exit( EXIT_FAILURE );
		case 0: // Code Runs Child Process
			processName = "This Is The Child Process";
			sleep( 5 );
			// Child Process Sending Signal SIGALRM TO Parent Process
			kill( getppid(), SIGALRM );
			exit( EXIT_SUCCESS );
		default: // Code Runs Parent Process
			processName = "This Is Parent Process";
	}
	
	printf("Waiting For Alarm To Go Off...\n");
	// Regitering SIGALRM Handler
	(void) signal( SIGALRM, signalHandlerFirst );
	
	pause(); 	
	if( alarmFired ) printf("Alarm Got Fired!!!...\n");
	printf("%s PID = %u PPID = %u\n", processName, getpid(), getppid() ) ;		
}
