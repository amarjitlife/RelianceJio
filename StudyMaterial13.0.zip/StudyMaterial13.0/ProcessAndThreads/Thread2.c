#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void * subRoutine1( void * dataAddress ) {
	int data = *((int *) dataAddress);	
	for ( int i = data ; i > 0 ; i-- ) {
		printf("On Thread1 : Running subRoutine1: %d\n", i) ;
		sleep( 1 );
	}

	return dataAddress;
}

void * subRoutine2( void * dataAddress ) {
	int data = *((int *) dataAddress);
	for ( int i = data ; i > 0 ; i-- ) { 
		printf("On Thread2 : Running subRoutine2: %d\n", i) ;
		sleep( 1 );
	}
	return dataAddress;
}
// All Thread Runs Independently In Same Process
//		i.e. Thread Runs Asynchronously
// Thread : Exection Path
// 		Creating Main Thread/Exection Path1 By Default
int main() { // Main Thread
	pthread_t Thread1, Thread2;
	int result1, result2;

	int data1 = 5;
	int data2 = 3;

	// Creating One More Thread/Execution Path2 Having Name Thread1
	//		Registing Sub Routine Named subRoutine1 To Be Executed
	//			 On Execution Path2 i.e. Thread1
	result1 = pthread_create( &Thread1, NULL, *subRoutine1, (void *) &data1 );	

	// Creating One More Thread/Execution Path3 Having Name Thread2
	//		Registing Sub Routine Named subRoutine2 To Be Executed
	//			 On Execution Path3 i.e. Thread2
	result2 = pthread_create( &Thread2, NULL, *subRoutine2, (void *) &data2 );

	printf("Thread1 Result: %d\n", result1);
	printf("Thread2 Result: %d\n", result2);

	for ( int i = 0 ; i < 5 ; i++ ) {
		printf("Main Thread... %d\n", i);
		sleep( 1 );	
	}

	// sleep( 5 );
	// pthread_join Will Make Calling Thread To Wait
	// 		i.e. Making Main Thred To Wait For Thread1 and Thread2 To Complete
	pthread_join( Thread1, NULL );
	pthread_join( Thread2, NULL );
	return 0;
}

