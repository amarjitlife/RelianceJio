#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define BLACK   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define CYAN    "\033[1;36m"

#define NUM_THREADS 5

long int commonData = 111 ; 
  
void * doSomething( void * data ) {
    commonData = commonData + (long) data;
    printf( "%s \tExecuting Thread  = %ld \n", RED , (long) data );
    sleep( 1 );
}

void * doSomethingAgain( void * data ) {
    commonData = commonData - (long) data;
    printf( "%s \tExecuting Thread Again = %ld \n", YELLOW, (long) data );
    sleep( 1 );
}
 
int main() {
    pthread_t threads[ NUM_THREADS ];
    pthread_t threadsAgain[ NUM_THREADS ];

    for (long int count = 0 ; count < NUM_THREADS ; ++count ) {
        int result;
        result = pthread_create( &threads[ count ], NULL, 
                                        doSomething, (void *) count ); 
        if (result != 0) {
            printf("Thread Creation Failed!...");
        } else {
            printf("%sCreated Thread = %ld \n", BLACK, count );            
        }

        result = pthread_create( &threadsAgain[ count ], NULL, 
                                    doSomethingAgain, (void *) count ); 
        if (result != 0) {
            printf("Thread Creation Failed!...");
        } else {
            printf("%sCreated Thread Again = %ld \n", BLACK, count );            
        }
    }

    printf("%sFinal Value Of commonData = %ld\n", BLUE, commonData );
    sleep( 10 );

    return 0;
}
