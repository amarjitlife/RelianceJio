#include <stdio.h>
#include <unistd.h>

int main() {
    int flag = 1;

    while ( flag <= 10 ) {
        printf("Hello World!\n"); 
        sleep( 1 );
        flag++;
    }
}

