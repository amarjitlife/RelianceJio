#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main( int argc, char ** argv ) {
	pid_t childPID;
	char *processName;

	printf("Forking Process...\n");
	childPID = fork();

	switch( childPID ) {
		case -1: 
			printf("Forking Failed!\n"); 
			exit( EXIT_FAILURE );
		case 0: // Code Runs Child Process
			processName = "Child Process";
			char *names[] = { "Amarjit Singh", "Rohan", "Rohit" };
			execv( "./greetings", names );
			break;
		default: // Code Runs Parent Process
			processName = "Parent Process";
	}

	wait(NULL);

	printf("%s PID = %u PPID = %u\n", processName, getpid(), getppid() ) ;		
}
