#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void * subRoutine1( void * dataAddress ) {
	int data = *((int *) dataAddress);	
	for ( int i = data ; i > 0 ; i-- ) 
		printf("On Thread1 : Doing Something: %d\n", i) ;
	return dataAddress;
}

void * subRoutine2( void * dataAddress ) {
	int data = *((int *) dataAddress);
	for ( int i = data ; i > 0 ; i-- ) 
		printf("On Thread2 : Doing Something: %d\n", i) ;
	return dataAddress;
}

// Thread : Exection Path
//	 In This Code Only One Exection Path Is There
//	 This Execution Path Is Called Main Thread
int main() { // Main Thread : 
	int data1 = 5;
	int data2 = 3;

	subRoutine1( (void *) &data1 );

	subRoutine2( (void *) &data2 );

	for ( int i = 0 ; i < 5 ; i++ ) 
		printf("Main Thread... %d\n", i);	

	sleep( 5 );

	return 0;
}

