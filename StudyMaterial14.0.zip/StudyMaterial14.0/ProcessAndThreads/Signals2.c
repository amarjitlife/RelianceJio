#include <signal.h>
#include <stdio.h>
#include <unistd.h>

struct sigaction old_act;

void signalHandlerFirst(int sig) {
	printf("Got Signal SIGINT :  %d\n", sig);
	// Resetting To DEFAULT SETTINGs For Signal SIGINT
	sigaction(SIGINT, &old_act, NULL);
}

int main() {
	struct sigaction act;

	// Registering Signal Handler
	act.sa_handler = signalHandlerFirst;
	sigemptyset( &act.sa_mask );
	act.sa_flags = 0;

	// The third arg, if non-NULL, is a place to save the old action. 
	// 	It's ignored if null.
	sigaction( SIGINT, &act, &old_act);

  	while(1) {
		printf("Hello World!\n");
		sleep(1);
  	}
}

