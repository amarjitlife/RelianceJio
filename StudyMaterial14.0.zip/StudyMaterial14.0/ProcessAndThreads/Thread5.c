#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
 
#define NUM_THREADS 10
 
#define BLACK   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define CYAN    "\033[1;36m"

static pthread_mutex_t mutex;

void * PrintAsciiText( void * data ) {
    char * colour;

    pthread_mutex_lock( &mutex );
    
    switch( (long) data % 5 ) {
        case 0:  colour = RED;       break;
        case 1:  colour = GREEN;     break;
        case 2:  colour = YELLOW;    break;
        case 3:  colour = BLUE;      break;
        case 4:  colour = CYAN;      break;
        default: colour = BLACK;     break;
    }
    printf( "%s \tExecuting Thread  = %ld \n", colour, (long) data );
    
    pthread_mutex_unlock( &mutex );
    
    sleep( 1 );
    pthread_exit(NULL);
}
 
int main() {
    pthread_t threads[ NUM_THREADS ];
 
// In a for loop, 
    // Called the pthread_create() function NUM_THREADS times 
    //     to create NUM_THREADS different threads. 
    // pthread_create() Takes Four Parameters:
    //     &threads[i] – The function returns the thread id of each thread it creates, 
    //             which is store in the p_threads array threads[ NUM_THREADS ].
    //     NULL – Telling pthread_create to use all the default thread attributes 
    //             to create the thread.
    //     PrintAsciiText – This is the subroutine that the thread is going to execute 
    //             once it is created.
    //     (void*) count – This is an identification number that passing onto 
    //             the subroutine as an argument. There are a maximum of NUM_THREADS threads, 
    //             so this value will be between 0 and NUM_THREADS.

    for (long int count = 0 ; count < NUM_THREADS ; ++count ) {
        int result = pthread_create( &threads[ count ], NULL, 
                                        PrintAsciiText, (void *) count ); 
        if (result != 0) {
            printf("Thread Creation Failed!...");
        } else {
            printf("%sCreated Thread = %ld \n", BLACK, count );            
        }
    }

    // See What Will Be Output If You Comment Folloiwng All for Loop Code 
    for(long int count = 0 ; count < NUM_THREADS; ++count ) {
        void * status;
        int result = pthread_join( threads[ count ], &status );
        
        if (result != 0) {
            printf("Thread Joining Failed!...: %d", result);
        } else {
            printf("%sJoined Thread = %ld \n", GREEN, count );            
        }
    }

    return 0;
}
