#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define BLACK   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define CYAN    "\033[1;36m"

#define NUM_THREADS 5

long int commonData = 111 ; 
  
void * doSomething( void * data ) {
    commonData = commonData + (long) data;
    printf( "%s \tExecuting Thread  = %ld \n", RED , (long) data );
    sleep( 1 );
}

void * doSomethingAgain( void * data ) {
    commonData = commonData * (long) data;
    printf( "%s \tExecuting Thread Again = %ld \n", YELLOW, (long) data );
    sleep( 1 );
}
 
int main() {
    pthread_t threads;
    pthread_t threadsAgain;
    int result;

    printf("%sValue Of commonData = %ld\n", BLUE, commonData );

    result = pthread_create( &threads, NULL, doSomething, (void *) 1 ); 
    if (result != 0) {
        printf("Thread Creation Failed!...");
    } else {
        printf("%sCreated Thread = %d \n", BLACK, 1 );            
    }

    printf("%sValue Of commonData = %ld\n", BLUE, commonData );

    result = pthread_create( &threadsAgain, NULL, doSomethingAgain, (void *) 2 ); 
    if (result != 0) {
        printf("Thread Creation Failed!...");
    } else {
        printf("%sCreated Thread Again = %d \n", BLACK, 2 );            
    }

    printf("%sValue Of commonData = %ld\n", BLUE, commonData );

    pthread_join( threads, NULL );
    pthread_join( threadsAgain, NULL );

// Race Condition Exists In This Code
//      Final commonData Value Will Be 
//      223 or 224 Depending On Which Order Threads Runs
//      i.e. Thread1 and Then Thread2 OR Thread2 and Then Thread1
    printf("%sFinal Value Of commonData = %ld\n", BLUE, commonData );
    return 0;
}
