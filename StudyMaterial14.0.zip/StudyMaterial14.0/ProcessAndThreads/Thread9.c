#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define BLACK   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define CYAN    "\033[1;36m"

#define NUM_THREADS 2

pthread_mutex_t mutex;

int commonA = 1 ; 
int commonB = 1 ; 

void * doSomething( void * data ) {
    // Mark Following Two Lines As Critical Section
    //      i.e. Have To Execute Both Of Them Completely In Single Go
    //           Making Following Lines Atomic Statements
    pthread_mutex_lock( &mutex );
    commonA = commonA + 1;
    commonB = commonB + 1;
    pthread_mutex_unlock( &mutex );
    
    printf( "%s \tExecuting Thread  = %ld \n", RED , (long) data );
    sleep( 1 );
}

void * doSomethingAgain( void * data ) {
    // Mark Following Two Lines As Critical Section
    //      i.e. Have To Execute Both Of Them Completely In Single Go
    //           Making Following Lines Atomic Statements
    pthread_mutex_lock( &mutex );
    commonB = commonB * 2 ;
    commonA = commonA * 2 ;
    pthread_mutex_unlock( &mutex );

    printf( "%s \tExecuting Thread Again = %ld \n", YELLOW, (long) data );
    sleep( 1 );
}
 
int main() {
    pthread_t threads[ NUM_THREADS ];
    pthread_t threadsAgain[ NUM_THREADS ];
    int result;

    result = pthread_mutex_init( &mutex, NULL );
    if (result != 0) {
        printf("Mutex Initialisation Failed!...");
    } else {
        printf("%sCreated Mutex Variable...\n", BLACK );            
    }

    for (long int count = 0 ; count < NUM_THREADS ; ++count ) {
        int result;
        result = pthread_create( &threads[ count ], NULL, 
                                        doSomething, (void *) count ); 
        if (result != 0) {
            printf("Thread Creation Failed!...");
        } else {
            printf("%sCreated Thread = %ld \n", BLACK, count );            
        }

        result = pthread_create( &threadsAgain[ count ], NULL, 
                                    doSomethingAgain, (void *) count ); 
        if (result != 0) {
            printf("Thread Creation Failed!...");
        } else {
            printf("%sCreated Thread Again = %ld \n", BLACK, count );            
        }
    }

    for(long int count = 0 ; count < NUM_THREADS; ++count ) {
        void * status;
        int result = pthread_join( threads[ count ], &status );
        
        if (result != 0) {
            printf("Thread Joining Failed!...: %d", result);
        } else {
            printf("%sJoined Thread = %ld \n", GREEN, count );            
        }
    }

    // This Need Not To Be Made Critical Section
    //      Because Here Only One Thread Will Access It i.e. Main Thread
    int commonData = commonA + commonB;

    printf("%sFinal Value Of commonData = %d\n", BLUE, commonData );

    pthread_mutex_destroy( &mutex );

    return 0;
}
