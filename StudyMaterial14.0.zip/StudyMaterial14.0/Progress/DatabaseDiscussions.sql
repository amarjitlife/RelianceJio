
//________________________________________________________________
//
//						MYSQL ENVIRONMENT
//________________________________________________________________

DATABASES
	COLLECTION OF TABLES
	WE CAN QUERY DATABASE USING SQL LANGAUGE

RELATIONAL DATABASE SYSTEMS ( RDBMS )

TABLE
	COLLECTION OF ROWS AND EACH ROW HAVE COLUMNS
	IT IS DATA STORE/FILE HAVING ROW AND COLUMN FORMAT 


SQL : Structured Query Language
	1. Case Insensitive
		Lower Cases And Upper Cases Are Same In Meanting


//___________________________________________________________________

AutoShop Organisation Have Following Entities
	Department
	Employee
	Customer
	Car

Relationships Between These Entities Are As Follows
	Each Department may have 0 or more Employees 
	Each Employee may have 0 or 1 Manager
	Each Customer may have 0 or more Cars

Generally For Each ENTITY We Have One Table


Entity
	Something of interest to the database user community. 
	Examples include customers, parts, geographic locations, etc.

	Entities Have Attributes
	Every Entity Will Generally Have One Or More TABLES

TABLE 
	A set of rows, held either in memory (nonpersistent) or 
	on permanent storage (persistent).

Column
	An individual piece of data stored in a table.
	For Each Attribute There Will Be One column

Schema
	Set Of Columns Attributes
	It Defines Table Columns Attributes

	Customers Table Schema : Set Of Column Attributes 
		+----+---------+--------+--------+-------------+------------------+
		| Id | FName   | LName  | Email  | PhoneNumber | PreferredContact |
		+----+---------+--------+--------+-------------+------------------+
	
	Cars Table Schema : : Set Of Column Attributes 
		+----+------------+------------+--------------+---------+-----------+
		| Id | CustomerId | EmployeeId | Model        | Status  | TotalCost |
		+----+------------+------------+--------------+---------+-----------+

Row
	A set of columns that together completely describe an entity 
	or some action on an entity. Also called a record. 


Result Set 
	Another name for a nonpersistent table, generally the result of an SQL query.

Primary key 
	One or more columns that can be used as a unique identifier 
		for each row in a table.

Foreign key
	One or more columns that can be used together to identify 
		a single row in another table.




//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!




