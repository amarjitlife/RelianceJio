
package something

open class Spiderman {
	open fun fly() { 
		println( "Fly Like Spiderman!") 
	}

	open fun saveWorld() {
		println( "Save World Like Spiderman!") 		
	}	
}

open class Superman {
	open fun fly() { 
		println( "Fly Like Superman!") 
	}

	open fun saveWorld() {
		println( "Save World Like Superman!") 		
	}	
}

// Inheritance
//		Doing Code Resuse From Parent Class
// class Human : Spiderman() {
class Human : Superman() {
	override fun fly() { 
		// println( "Fly Like Humnan!") 
		super.fly()
	}

	override fun saveWorld() {
		// println( "Save World Like Humnan!") 		
		super.saveWorld()
	}
}

fun main() {
	var spiderman = Spiderman()
	spiderman.fly()
	spiderman.saveWorld()

	val human = Human() 
	human.fly()
	human.saveWorld()
}

