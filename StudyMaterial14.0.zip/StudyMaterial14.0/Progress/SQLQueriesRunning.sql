    mysql> CREATE DATABASE Toyota;
    Query OK, 1 row affected (0.01 sec)

    mysql> show databases;
    +--------------------+
    | Database           |
    +--------------------+
    | Toyota             |
    | information_schema |
    | mysql              |
    | performance_schema |
    | sakila             |
    | sys                |
    +--------------------+
    6 rows in set (0.00 sec)

    mysql> use Toyota;
    Database changed
    mysql> show tables;
    Empty set (0.00 sec)

    mysql> CREATE TABLE Departments (
        ->     Id INT NOT NULL AUTO_INCREMENT,
        ->     Name VARCHAR(25) NOT NULL,
        ->     PRIMARY KEY(Id)
        -> );
    Query OK, 0 rows affected (0.05 sec)

    mysql> show tables;
    +------------------+
    | Tables_in_Toyota |
    +------------------+
    | Departments      |
    +------------------+
    1 row in set (0.01 sec)

    mysql> 
    mysql> INSERT INTO Departments
        ->     (Id, Name)
        -> VALUES
        ->     (1, 'HR'),
        ->     (2, 'Sales'),
        ->     (3, 'Tech')
        -> ;
    Query OK, 3 rows affected (0.01 sec)
    Records: 3  Duplicates: 0  Warnings: 0

    mysql> 
    mysql> show tables;
    +------------------+
    | Tables_in_Toyota |
    +------------------+
    | Departments      |
    +------------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM Departments;
    +----+-------+
    | Id | Name  |
    +----+-------+
    |  1 | HR    |
    |  2 | Sales |
    |  3 | Tech  |
    +----+-------+
    3 rows in set (0.00 sec)

    mysql> show tables;
    +------------------+
    | Tables_in_Toyota |
    +------------------+
    | Departments      |
    +------------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> DROP DATABASE Toyota
        -> 
        -> ;
    Query OK, 1 row affected (0.04 sec)

    mysql> 
    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | information_schema |
    | mysql              |
    | performance_schema |
    | sakila             |
    | sys                |
    +--------------------+
    5 rows in set (0.00 sec)

    mysql> 
    mysql> 

    ____________________________________________________________________
    ____________________________________________________________________
    ____________________________________________________________________


    mysql> 
    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | information_schema |
    | mysql              |
    | performance_schema |
    | sys                |
    +--------------------+
    4 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> CREATE DATABASE autoshop;
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | autoshop           |
    | information_schema |
    | mysql              |
    | performance_schema |
    | sys                |
    +--------------------+
    5 rows in set (0.00 sec)

    mysql> 
    mysql> use autoshop;
    Database changed
    mysql> 
    mysql> 
    mysql> show tables;
    Empty set (0.00 sec)

    mysql> 
    mysql> -- schema
    mysql> CREATE TABLE Departments (
        ->     Id INT NOT NULL AUTO_INCREMENT,
        ->     Name VARCHAR(25) NOT NULL,
        ->     PRIMARY KEY(Id)
        -> );
    Query OK, 0 rows affected (0.03 sec)

    mysql> 
    mysql> CREATE TABLE Employees (
        ->     Id INT NOT NULL AUTO_INCREMENT,
        ->     FName VARCHAR(35) NOT NULL,
        ->     LName VARCHAR(35) NOT NULL,
        ->     PhoneNumber VARCHAR(11),
        ->     ManagerId INT,
        ->     DepartmentId INT NOT NULL,
        ->     Salary INT NOT NULL,
        ->     HireDate DATETIME NOT NULL,
        ->     PRIMARY KEY(Id),
        ->     FOREIGN KEY (ManagerId) REFERENCES Employees(Id),
        ->     FOREIGN KEY (DepartmentId) REFERENCES Departments(Id)
        -> );
    Query OK, 0 rows affected (0.06 sec)

    mysql> 
    mysql> CREATE TABLE Customers (
        ->     Id INT NOT NULL AUTO_INCREMENT,
        ->     FName VARCHAR(35) NOT NULL,
        ->     LName VARCHAR(35) NOT NULL,
        ->     Email varchar(100) NOT NULL,
        ->     PhoneNumber VARCHAR(11),
        ->     PreferredContact VARCHAR(5) NOT NULL,
        ->     PRIMARY KEY(Id)
        -> );
    Query OK, 0 rows affected (0.03 sec)

    mysql> 
    mysql> CREATE TABLE Cars (
        ->     Id INT NOT NULL AUTO_INCREMENT,
        ->     CustomerId INT NOT NULL,
        ->     EmployeeId INT NOT NULL,
        ->     Model varchar(50) NOT NULL,
        ->     Status varchar(25) NOT NULL,
        ->     TotalCost INT NOT NULL,
        ->     PRIMARY KEY(Id),
        ->     FOREIGN KEY (CustomerId) REFERENCES Customers(Id),
        ->     FOREIGN KEY (EmployeeId) REFERENCES Employees(Id)
        -> );
    Query OK, 0 rows affected (0.05 sec)

    mysql> 
    mysql> -- data
    mysql> INSERT INTO Departments
        ->     (Id, Name)
        -> VALUES
        ->     (1, 'HR'),
        ->     (2, 'Sales'),
        ->     (3, 'Tech')
        -> ;
    Query OK, 3 rows affected (0.01 sec)
    Records: 3  Duplicates: 0  Warnings: 0

    mysql> 
    mysql> INSERT INTO Employees
        ->     (Id, FName, LName, PhoneNumber, ManagerId, DepartmentId, Salary, HireDate)
        -> VALUES
        ->     (1, 'James', 'Smith', 1234567890, NULL, 1, 1000, str_to_date('01-01-2002', '%d-%m-%Y')),
        ->     (2, 'John', 'Johnson', 2468101214, '1', 1, 400, str_to_date('23-03-2005', '%d-%m-%Y')),
        ->     (3, 'Michael', 'Williams', 1357911131, '1', 2, 600, str_to_date('12-05-2009', '%d-%m-%Y')),
        ->     (4, 'Johnathon', 'Smith', 1212121212, '2', 1, 500, str_to_date('24-07-2016', '%d-%m-%Y'))
        -> ;
    Query OK, 4 rows affected (0.00 sec)
    Records: 4  Duplicates: 0  Warnings: 0

    mysql> 
    mysql> INSERT INTO Customers
        ->     (Id, FName, LName, Email, PhoneNumber, PreferredContact)
        -> VALUES
        ->     (1, 'William', 'Jones', 'william.jones@example.com', '3347927472', 'PHONE'),
        ->     (2, 'David', 'Miller', 'dmiller@example.net', '2137921892', 'EMAIL'),
        ->     (3, 'Richard', 'Davis', 'richard0123@example.com', NULL, 'EMAIL')
        -> ;
    Query OK, 3 rows affected (0.01 sec)
    Records: 3  Duplicates: 0  Warnings: 0

    mysql> 
    mysql> INSERT INTO Cars
        ->     (Id, CustomerId, EmployeeId, Model, Status, TotalCost)
        -> VALUES
        ->     ('1', '1', '2', 'Ford F-150', 'READY', '230'),
        ->     ('2', '1', '2', 'Ford F-150', 'READY', '200'),
        ->     ('3', '2', '1', 'Ford Mustang', 'WAITING', '100'),
        ->     ('4', '3', '3', 'Toyota Prius', 'WORKING', '1254')
        -> ;
    Query OK, 4 rows affected (0.01 sec)
    Records: 4  Duplicates: 0  Warnings: 0

    mysql> 
    mysql> 
    mysql> show tables
        -> ;
    +--------------------+
    | Tables_in_autoshop |
    +--------------------+
    | Cars               |
    | Customers          |
    | Departments        |
    | Employees          |
    +--------------------+
    4 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT * from Cars;
    +----+------------+------------+--------------+---------+-----------+
    | Id | CustomerId | EmployeeId | Model        | Status  | TotalCost |
    +----+------------+------------+--------------+---------+-----------+
    |  1 |          1 |          2 | Ford F-150   | READY   |       230 |
    |  2 |          1 |          2 | Ford F-150   | READY   |       200 |
    |  3 |          2 |          1 | Ford Mustang | WAITING |       100 |
    |  4 |          3 |          3 | Toyota Prius | WORKING |      1254 |
    +----+------------+------------+--------------+---------+-----------+
    4 rows in set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM CUSTOMERS;
    ERROR 1146 (42S02): Table 'autoshop.CUSTOMERS' doesn't exist
    mysql> 
    mysql> 
    mysql> SELECT * FROM Customers;
    +----+---------+--------+---------------------------+-------------+------------------+
    | Id | FName   | LName  | Email                     | PhoneNumber | PreferredContact |
    +----+---------+--------+---------------------------+-------------+------------------+
    |  1 | William | Jones  | william.jones@example.com | 3347927472  | PHONE            |
    |  2 | David   | Miller | dmiller@example.net       | 2137921892  | EMAIL            |
    |  3 | Richard | Davis  | richard0123@example.com   | NULL        | EMAIL            |
    +----+---------+--------+---------------------------+-------------+------------------+
    3 rows in set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM Departments;
    +----+-------+
    | Id | Name  |
    +----+-------+
    |  1 | HR    |
    |  2 | Sales |
    |  3 | Tech  |
    +----+-------+
    3 rows in set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM Cars;
    +----+------------+------------+--------------+---------+-----------+
    | Id | CustomerId | EmployeeId | Model        | Status  | TotalCost |
    +----+------------+------------+--------------+---------+-----------+
    |  1 |          1 |          2 | Ford F-150   | READY   |       230 |
    |  2 |          1 |          2 | Ford F-150   | READY   |       200 |
    |  3 |          2 |          1 | Ford Mustang | WAITING |       100 |
    |  4 |          3 |          3 | Toyota Prius | WORKING |      1254 |
    +----+------------+------------+--------------+---------+-----------+
    4 rows in set (0.00 sec)

    mysql> 
    mysql> 


    -----------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------


    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | autoshop           |
    | information_schema |
    | mysql              |
    | performance_schema |
    | sys                |
    +--------------------+
    5 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> source /home/khoj/Documents/LearnDatabase/sakila-db/sakila-schema.sql

    Query OK, 0 rows affected (0.00 sec)

    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | autoshop           |
    | information_schema |
    | mysql              |
    | performance_schema |
    | sakila             |
    | sys                |
    +--------------------+
    6 rows in set (0.00 sec)

    mysql> use sakila 
    Database changed
    mysql> 
    mysql> show tables;
    +----------------------------+
    | Tables_in_sakila           |
    +----------------------------+
    | actor                      |
    | actor_info                 |
    | address                    |
    | category                   |
    | city                       |
    | country                    |
    | customer                   |
    | customer_list              |
    | film                       |
    | film_actor                 |
    | film_category              |
    | film_list                  |
    | film_text                  |
    | inventory                  |
    | language                   |
    | nicer_but_slower_film_list |
    | payment                    |
    | rental                     |
    | sales_by_film_category     |
    | sales_by_store             |
    | staff                      |
    | staff_list                 |
    | store                      |
    +----------------------------+
    23 rows in set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM city;
    Empty set (0.00 sec)

    mysql> 
    mysql> SELECT * FROM actor;
    Empty set (0.01 sec)

    mysql> 
    mysql> 
    mysql> source /home/khoj/Documents/LearnDatabase/sakila-db/sakila-data.sql
    Query OK, 0 rows affected (0.00 sec)

    Query OK, 0 rows affected (0.00 sec)

    Query OK, 0 rows affected (0.00 sec)

    mysql> SELECT * FROM city;
    +---------+----------------------------+------------+---------------------+
    | city_id | city                       | country_id | last_update         |
    +---------+----------------------------+------------+---------------------+
    |       1 | A Corua (La Corua)         |         87 | 2006-02-15 04:45:25 |
    |       2 | Abha                       |         82 | 2006-02-15 04:45:25 |
    |       3 | Abu Dhabi                  |        101 | 2006-02-15 04:45:25 |
    |       4 | Acua                       |         60 | 2006-02-15 04:45:25 |
    |       5 | Adana                      |         97 | 2006-02-15 04:45:25 |

    600 rows in set (0.00 sec)

    mysql> SELECT * FROM actor;
    +----------+-------------+--------------+---------------------+
    | actor_id | first_name  | last_name    | last_update         |
    +----------+-------------+--------------+---------------------+
    |        1 | PENELOPE    | GUINESS      | 2006-02-15 04:34:33 |
    |        2 | NICK        | WAHLBERG     | 2006-02-15 04:34:33 |
    |        3 | ED          | CHASE        | 2006-02-15 04:34:33 |
    200 rows in set (0.00 sec)

    mysql> 
    mysql>


    -----------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------

    --
    -- Table structure for table `actor`
    --

    CREATE TABLE actor (
      actor_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
      first_name VARCHAR(45) NOT NULL,
      last_name VARCHAR(45) NOT NULL,
      last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY  (actor_id),
      KEY idx_actor_last_name (last_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


    // Will Give Schema With Contraints On Column Data
    mysql> describe actor;
    +-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
    | Field       | Type              | Null | Key | Default           | Extra                                         |
    +-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
    | actor_id    | smallint unsigned | NO   | PRI | NULL              | auto_increment                                |
    | first_name  | varchar(45)       | NO   |     | NULL              |                                               |
    | last_name   | varchar(45)       | NO   | MUL | NULL              |                                               |
    | last_update | timestamp         | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
    +-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
    4 rows in set (0.00 sec)

    --
    -- Table structure for table `language`
    --

    CREATE TABLE language (
      language_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
      name CHAR(20) NOT NULL,
      last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (language_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


    mysql> describe language;
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | Field       | Type             | Null | Key | Default           | Extra                                         |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | language_id | tinyint unsigned | NO   | PRI | NULL              | auto_increment                                |
    | name        | char(20)         | NO   |     | NULL              |                                               |
    | last_update | timestamp        | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    3 rows in set (0.01 sec)


    mysql> desc language;
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | Field       | Type             | Null | Key | Default           | Extra                                         |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | language_id | tinyint unsigned | NO   | PRI | NULL              | auto_increment                                |
    | name        | char(20)         | NO   |     | NULL              |                                               |
    | last_update | timestamp        | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    3 rows in set (0.00 sec)


    _____________________________________________________________________________________
    _____________________________________________________________________________________



    CREATE TABLE person
         (person_id SMALLINT UNSIGNED,
          fname VARCHAR(20),
          lname VARCHAR(20),
          eye_color CHAR(2),
          birth_date DATE,
          street VARCHAR(30),
          city VARCHAR(20),
          state VARCHAR(20),
          country VARCHAR(20),
          postal_code VARCHAR(20),
          CONSTRAINT pk_person PRIMARY KEY (person_id)
    );

    CREATE TABLE person
         (person_id SMALLINT UNSIGNED,
          fname VARCHAR(20),
          lname VARCHAR(20),
          eye_color ENUM('BR','BL','GR'),
          birth_date DATE,
          street VARCHAR(30),
          city VARCHAR(20),
          state VARCHAR(20),
          country VARCHAR(20),
          postal_code VARCHAR(20),
          CONSTRAINT pk_person PRIMARY KEY (person_id)
    );


    _____________________________________________________________________________________
    _____________________________________________________________________________________

    mysql> CREATE DATABASE Human;
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> SHOW DATABASES;
    +--------------------+
    | Database           |
    +--------------------+
    | Human              |
    | autoshop           |
    | information_schema |
    | mysql              |
    | performance_schema |
    | sakila             |
    | sys                |
    +--------------------+
    7 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> use Human;
    Database changed
    mysql> 
    mysql> SHOW TABLES;
    Empty set (0.00 sec)

    mysql> 
    mysql> 
    mysql> CREATE TABLE person
        ->      (person_id SMALLINT UNSIGNED,
        ->       fname VARCHAR(20),
        ->       lname VARCHAR(20),
        ->       eye_color ENUM('BR','BL','GR'),
        ->       birth_date DATE,
        ->       street VARCHAR(30),
        ->       city VARCHAR(20),
        ->       state VARCHAR(20),
        ->       country VARCHAR(20),
        ->       postal_code VARCHAR(20),
        ->       CONSTRAINT pk_person PRIMARY KEY (person_id)
        ->      );
    Query OK, 0 rows affected (0.04 sec)

    mysql> 
    mysql> 
    mysql> CREATE TABLE favorite_food
        ->      (person_id SMALLINT UNSIGNED,
        ->      food VARCHAR(20),
        ->      CONSTRAINT pk_favorite_food PRIMARY KEY (person_id, food),
        ->      CONSTRAINT fk_fav_food_person_id FOREIGN KEY (person_id)
        ->      REFERENCES person (person_id)
        ->      );
    Query OK, 0 rows affected (0.05 sec)

    mysql> 
    mysql> 
    mysql> 
    mysql> SHOW TABLES;
    +-----------------+
    | Tables_in_Human |
    +-----------------+
    | favorite_food   |
    | person          |
    +-----------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> 
    mysql> desc person
        -> ;
    +-------------+----------------------+------+-----+---------+-------+
    | Field       | Type                 | Null | Key | Default | Extra |
    +-------------+----------------------+------+-----+---------+-------+
    | person_id   | smallint unsigned    | NO   | PRI | NULL    |       |
    | fname       | varchar(20)          | YES  |     | NULL    |       |
    | lname       | varchar(20)          | YES  |     | NULL    |       |
    | eye_color   | enum('BR','BL','GR') | YES  |     | NULL    |       |
    | birth_date  | date                 | YES  |     | NULL    |       |
    | street      | varchar(30)          | YES  |     | NULL    |       |
    | city        | varchar(20)          | YES  |     | NULL    |       |
    | state       | varchar(20)          | YES  |     | NULL    |       |
    | country     | varchar(20)          | YES  |     | NULL    |       |
    | postal_code | varchar(20)          | YES  |     | NULL    |       |
    +-------------+----------------------+------+-----+---------+-------+
    10 rows in set (0.00 sec)

    mysql> 
    mysql> desc favorite_food;
    +-----------+-------------------+------+-----+---------+-------+
    | Field     | Type              | Null | Key | Default | Extra |
    +-----------+-------------------+------+-----+---------+-------+
    | person_id | smallint unsigned | NO   | PRI | NULL    |       |
    | food      | varchar(20)       | NO   | PRI | NULL    |       |
    +-----------+-------------------+------+-----+---------+-------+
    2 rows in set (0.01 sec)

    mysql> 
    mysql> 

    _____________________________________________________________________________________
    _____________________________________________________________________________________

    mysql> INSERT INTO person
        ->       (person_id, fname, lname, eye_color, birth_date)
        ->     VALUES (null, 'William','Turner', 'BR', '1972-05-27');
    ERROR 1048 (23000): Column 'person_id' cannot be null
    mysql> 
    mysql> 
    mysql> 
    mysql> INSERT INTO person       (person_id, fname, lname, eye_color, birth_date)     VALUES (10, 'William','Turner', 'BR', '1972-05-27');
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> SELECT * from person;
    +-----------+---------+--------+-----------+------------+--------+------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street | city | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+--------+------+-------+---------+-------------+
    |        10 | William | Turner | BR        | 1972-05-27 | NULL   | NULL | NULL  | NULL    | NULL        |
    +-----------+---------+--------+-----------+------------+--------+------+-------+---------+-------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT person_id, fname, lname, birth_date
        ->     FROM person;   
    +-----------+---------+--------+------------+
    | person_id | fname   | lname  | birth_date |
    +-----------+---------+--------+------------+
    |        10 | William | Turner | 1972-05-27 |
    +-----------+---------+--------+------------+
    1 row in set (0.01 sec)

    mysql> 
    mysql> 
    mysql> SELECT person_id, fname, lname, birth_date
        ->     FROM person
        ->     WHERE person_id = 1;
    Empty set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT person_id, fname, lname, birth_date     FROM person     WHERE person_id = 10;
    +-----------+---------+--------+------------+
    | person_id | fname   | lname  | birth_date |
    +-----------+---------+--------+------------+
    |        10 | William | Turner | 1972-05-27 |
    +-----------+---------+--------+------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT person_id, fname, lname, birth_date
        ->     FROM person
        ->     WHERE lname = 'Turner';
    +-----------+---------+--------+------------+
    | person_id | fname   | lname  | birth_date |
    +-----------+---------+--------+------------+
    |        10 | William | Turner | 1972-05-27 |
    +-----------+---------+--------+------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT person_id, fname, lname, birth_date     FROM person     WHERE lname = 'Bhat';
    Empty set (0.00 sec)

    mysql> 
    mysql> desc person;
    +-------------+----------------------+------+-----+---------+-------+
    | Field       | Type                 | Null | Key | Default | Extra |
    +-------------+----------------------+------+-----+---------+-------+
    | person_id   | smallint unsigned    | NO   | PRI | NULL    |       |
    | fname       | varchar(20)          | YES  |     | NULL    |       |
    | lname       | varchar(20)          | YES  |     | NULL    |       |
    | eye_color   | enum('BR','BL','GR') | YES  |     | NULL    |       |
    | birth_date  | date                 | YES  |     | NULL    |       |
    | street      | varchar(30)          | YES  |     | NULL    |       |
    | city        | varchar(20)          | YES  |     | NULL    |       |
    | state       | varchar(20)          | YES  |     | NULL    |       |
    | country     | varchar(20)          | YES  |     | NULL    |       |
    | postal_code | varchar(20)          | YES  |     | NULL    |       |
    +-------------+----------------------+------+-----+---------+-------+
    10 rows in set (0.01 sec)

    mysql> 
    mysql> 
    mysql> desc favorite_food;
    +-----------+-------------------+------+-----+---------+-------+
    | Field     | Type              | Null | Key | Default | Extra |
    +-----------+-------------------+------+-----+---------+-------+
    | person_id | smallint unsigned | NO   | PRI | NULL    |       |
    | food      | varchar(20)       | NO   | PRI | NULL    |       |
    +-----------+-------------------+------+-----+---------+-------+
    2 rows in set (0.01 sec)

    mysql> 
    mysql> 
    mysql> INSERT INTO person
        ->     (person_id, fname, lname, eye_color, birth_date,
        ->     street, city, state, country, postal_code)
        ->     VALUES (null, 'Susan','Smith', 'BL', '1975-11-02',
        ->      '23 Maple St.', 'Arlington', 'VA', 'USA', '20220');
    ERROR 1048 (23000): Column 'person_id' cannot be null
    mysql> 
    mysql> 
    mysql> 
    mysql> INSERT INTO person     (person_id, fname, lname, eye_color, birth_date,     street, city, state,
    country, postal_code)     VALUES (1, 'Susan','Smith', 'BL', '1975-11-02',      '23 Maple St.', 'Arlington', 'VA', 'USA', '20220');
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street       | city      | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    |         1 | Susan   | Smith  | BL        | 1975-11-02 | 23 Maple St. | Arlington | VA    | USA     | 20220       |
    |        10 | William | Turner | BR        | 1972-05-27 | NULL         | NULL      | NULL  | NULL    | NULL        |
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 


    _____________________________________________________________________________________
    _____________________________________________________________________________________


    mysql> 
    mysql> 
    mysql> INSERT INTO person
        ->     (person_id, fname, lname, eye_color, birth_date,
        ->     street, city, state, country, postal_code)
        ->     VALUES (null, 'Susan','Smith', 'BL', '1975-11-02',
        ->      '23 Maple St.', 'Arlington', 'VA', 'USA', '20220');
    ERROR 1048 (23000): Column 'person_id' cannot be null
    mysql> 
    mysql> 
    mysql> 
    mysql> INSERT INTO person     (person_id, fname, lname, eye_color, birth_date,     street, city, state,
    country, postal_code)     VALUES (1, 'Susan','Smith', 'BL', '1975-11-02',      '23 Maple St.', 'Arlington', 'VA', 'USA', '20220');
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street       | city      | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    |         1 | Susan   | Smith  | BL        | 1975-11-02 | 23 Maple St. | Arlington | VA    | USA     | 20220       |
    |        10 | William | Turner | BR        | 1972-05-27 | NULL         | NULL      | NULL  | NULL    | NULL        |
    +-----------+---------+--------+-----------+------------+--------------+-----------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> UPDATE person
        ->     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        ->     WHERE person_id = 1;
    Query OK, 1 row affected (0.01 sec)
    Rows matched: 1  Changed: 1  Warnings: 0

    mysql> 
    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Susan   | Smith  | BL        | 1975-11-02 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    |        10 | William | Turner | BR        | 1972-05-27 | NULL             | NULL   | NULL  | NULL    | NULL        |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> UPDATE person
        ->     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        ->     WHERE person_id < 10
        -> 
        -> ;
    Query OK, 0 rows affected (0.00 sec)
    Rows matched: 1  Changed: 0  Warnings: 0

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Susan   | Smith  | BL        | 1975-11-02 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    |        10 | William | Turner | BR        | 1972-05-27 | NULL             | NULL   | NULL  | NULL    | NULL        |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql>     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        ->     WHERE person_id <= 10
        -> 
        -> ;
    ERROR 1193 (HY000): Unknown system variable 'street'
    mysql> 
    mysql> 
    mysql> UPDATE person
        ->     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        ->     WHERE person_id <= 10
        -> 
        -> ;
    Query OK, 1 row affected (0.00 sec)
    Rows matched: 2  Changed: 1  Warnings: 0

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Susan   | Smith  | BL        | 1975-11-02 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    |        10 | William | Turner | BR        | 1972-05-27 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> UPDATE person
        ->     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        -> ;
    Query OK, 0 rows affected (0.01 sec)
    Rows matched: 2  Changed: 0  Warnings: 0

    mysql> 
    mysql> 
    mysql> DELETE FROM person
        ->     WHERE person_id = 2;
    Query OK, 0 rows affected (0.00 sec)

    mysql> 
    mysql> DELETE FROM person     WHERE person_id = 1;
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |        10 | William | Turner | BR        | 1972-05-27 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    1 row in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> INSERT INTO person
        ->      (person_id, fname, lname, eye_color, birth_date)
        ->     VALUES (1, 'Charles','Fulton', 'GR', '1968-01-15');
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Charles | Fulton | GR        | 1968-01-15 | NULL             | NULL   | NULL  | NULL    | NULL        |
    |        10 | William | Turner | BR        | 1972-05-27 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    2 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> INSERT INTO person
        ->      (person_id, fname, lname, eye_color, birth_date)
        ->     VALUES (2, 'Charles','Millan', 'GR', '1968-01-15');
    Query OK, 1 row affected (0.01 sec)

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Charles | Fulton | GR        | 1968-01-15 | NULL             | NULL   | NULL  | NULL    | NULL        |
    |         2 | Charles | Millan | GR        | 1968-01-15 | NULL             | NULL   | NULL  | NULL    | NULL        |
    |        10 | William | Turner | BR        | 1972-05-27 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    3 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> UPDATE person
        ->     SET street = '1225 Tremont St.',
        ->       city = 'Boston',
        ->       state = 'MA',
        ->       country = 'USA',
        ->       postal_code = '02138'
        -> ;
    Query OK, 2 rows affected (0.01 sec)
    Rows matched: 3  Changed: 2  Warnings: 0

    mysql> 
    mysql> 
    mysql> select * from person;
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    | person_id | fname   | lname  | eye_color | birth_date | street           | city   | state | country | postal_code |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    |         1 | Charles | Fulton | GR        | 1968-01-15 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    |         2 | Charles | Millan | GR        | 1968-01-15 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    |        10 | William | Turner | BR        | 1972-05-27 | 1225 Tremont St. | Boston | MA    | USA     | 02138       |
    +-----------+---------+--------+-----------+------------+------------------+--------+-------+---------+-------------+
    3 rows in set (0.00 sec)

    mysql> 
    mysql> 
    _____________________________________________________________________________________
    _____________________________________________________________________________________

    mysql> use sakila;
    mysql> show tables;
    mysql> select * from custormer;
    mysql> SELECT first_name, last_name FROM customer WHERE last_name = 'ZIEGLER';
    mysql> SELECT first_name, last_name FROM customer WHERE last_name = 'SOUTH';

    _____________________________________________________________________________________
    _____________________________________________________________________________________

    mysql> SELECT * FROM language;
    +-------------+----------+---------------------+
    | language_id | name     | last_update         |
    +-------------+----------+---------------------+
    |           1 | English  | 2006-02-15 05:02:19 |
    |           2 | Italian  | 2006-02-15 05:02:19 |
    |           3 | Japanese | 2006-02-15 05:02:19 |
    |           4 | Mandarin | 2006-02-15 05:02:19 |
    |           5 | French   | 2006-02-15 05:02:19 |
    |           6 | German   | 2006-02-15 05:02:19 |
    +-------------+----------+---------------------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT language_id, name, last_update
        ->     FROM language;
    +-------------+----------+---------------------+
    | language_id | name     | last_update         |
    +-------------+----------+---------------------+
    |           1 | English  | 2006-02-15 05:02:19 |
    |           2 | Italian  | 2006-02-15 05:02:19 |
    |           3 | Japanese | 2006-02-15 05:02:19 |
    |           4 | Mandarin | 2006-02-15 05:02:19 |
    |           5 | French   | 2006-02-15 05:02:19 |
    |           6 | German   | 2006-02-15 05:02:19 |
    +-------------+----------+---------------------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT name
        ->     FROM language;
    +----------+
    | name     |
    +----------+
    | English  |
    | Italian  |
    | Japanese |
    | Mandarin |
    | French   |
    | German   |
    +----------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> SELECT name
        ->     FROM language;
    +----------+
    | name     |
    +----------+
    | English  |
    | Italian  |
    | Japanese |
    | Mandarin |
    | French   |
    | German   |
    +----------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> SELECT language_id,
        ->       'COMMON' language_usage,
        ->       language_id * 3.1415927 lang_pi_value,
        ->       upper(name) language_name
        ->     FROM language;
    +-------------+----------------+---------------+---------------+
    | language_id | language_usage | lang_pi_value | language_name |
    +-------------+----------------+---------------+---------------+
    |           1 | COMMON         |     3.1415927 | ENGLISH       |
    |           2 | COMMON         |     6.2831854 | ITALIAN       |
    |           3 | COMMON         |     9.4247781 | JAPANESE      |
    |           4 | COMMON         |    12.5663708 | MANDARIN      |
    |           5 | COMMON         |    15.7079635 | FRENCH        |
    |           6 | COMMON         |    18.8495562 | GERMAN        |
    +-------------+----------------+---------------+---------------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> desc language
        -> ;
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | Field       | Type             | Null | Key | Default           | Extra                                         |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    | language_id | tinyint unsigned | NO   | PRI | NULL              | auto_increment                                |
    | name        | char(20)         | NO   |     | NULL              |                                               |
    | last_update | timestamp        | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
    +-------------+------------------+------+-----+-------------------+-----------------------------------------------+
    3 rows in set (0.01 sec)

    mysql> SELECT version(),
        ->       user(),
        ->       database();
    +-------------------------+----------------+------------+
    | version()               | user()         | database() |
    +-------------------------+----------------+------------+
    | 8.0.29-0ubuntu0.22.04.2 | root@localhost | sakila     |
    +-------------------------+----------------+------------+
    1 row in set (0.00 sec)

    mysql> SELECT language_id,
        -> 'COMMON' language_usage,
        -> language_id * 3.1415927 lang_pi_value,
        -> upper(name) language_name FROM language;
    +-------------+----------------+---------------+---------------+
    | language_id | language_usage | lang_pi_value | language_name |
    +-------------+----------------+---------------+---------------+
    |           1 | COMMON         |     3.1415927 | ENGLISH       |
    |           2 | COMMON         |     6.2831854 | ITALIAN       |
    |           3 | COMMON         |     9.4247781 | JAPANESE      |
    |           4 | COMMON         |    12.5663708 | MANDARIN      |
    |           5 | COMMON         |    15.7079635 | FRENCH        |
    |           6 | COMMON         |    18.8495562 | GERMAN        |
    +-------------+----------------+---------------+---------------+
    6 rows in set (0.00 sec)

    mysql> 
    mysql> 
    mysql> 
    mysql> SELECT language_id,
        -> 'COMMON' AS language_usage,
        -> language_id * 3.1415927 AS lang_pi_value,
        -> upper(name) AS language_name FROM language;
    +-------------+----------------+---------------+---------------+
    | language_id | language_usage | lang_pi_value | language_name |
    +-------------+----------------+---------------+---------------+
    |           1 | COMMON         |     3.1415927 | ENGLISH       |
    |           2 | COMMON         |     6.2831854 | ITALIAN       |
    |           3 | COMMON         |     9.4247781 | JAPANESE      |
    |           4 | COMMON         |    12.5663708 | MANDARIN      |
    |           5 | COMMON         |    15.7079635 | FRENCH        |
    |           6 | COMMON         |    18.8495562 | GERMAN        |
    +-------------+----------------+---------------+---------------+
    6 rows in set (0.00 sec)

    mysql> 


    _____________________________________________________________________________________
    _____________________________________________________________________________________



    SELECT actor_id FROM film_actor ORDER BY actor_id;

    SELECT DISTINCT actor_id FROM film_actor ORDER BY actor_id;

    SELECT concat(cust.last_name, ', ', cust.first_name) full_name
    FROM
     ( SELECT first_name, last_name, email
      FROM customer
    WHERE first_name = 'JESSIE' ) cust;

    CREATE TEMPORARY TABLE actors_j
         (actor_id smallint(5),
          first_name varchar(45),
          last_name varchar(45)
         );    

    INSERT INTO actors_j
        SELECT actor_id, first_name, last_name
        FROM actor
        WHERE last_name LIKE 'J%';

    SELECT * FROM actors_j;


    _____________________________________________________________________________________
    _____________________________________________________________________________________


    CREATE VIEW cust_vw AS
        SELECT customer_id, first_name, last_name, active
        FROM customer;

    SELECT * FROM cust_vw

    SELECT first_name, last_name
        FROM cust_vw
        WHERE active = 0;    

    _____________________________________________________________________________________
    _____________________________________________________________________________________


    SELECT customer.first_name, customer.last_name,
          time(rental.rental_date) rental_time
        FROM customer
          INNER JOIN rental
        ON customer.customer_id = rental.customer_id
        WHERE date(rental.rental_date) = '2005-06-14';

    SELECT c.first_name, c.last_name,
        time(r.rental_date) rental_time
    FROM customer c
        INNER JOIN rental r
        ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14';


    SELECT c.first_name, c.last_name,
      time(r.rental_date) rental_time
    FROM customer AS c
    INNER JOIN rental AS r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14';

    SELECT title
        FROM film
    WHERE rating = 'G' AND rental_duration >= 7;

    SELECT title
        FROM film
    WHERE rating = 'G' OR rental_duration >= 7;

    SELECT title, rating, rental_duration
        FROM film
        WHERE (rating = 'G' AND rental_duration >= 7)
          OR (rating = 'PG-13' AND rental_duration < 4);

    SELECT c.first_name, c.last_name, count(*)
        FROM customer c
          INNER JOIN rental r
          ON c.customer_id = r.customer_id
        GROUP BY c.first_name, c.last_name
        HAVING count(*) >= 40;

    SELECT c.first_name, c.last_name,
          time(r.rental_date) rental_time
        FROM customer c
          INNER JOIN rental r
          ON c.customer_id = r.customer_id
        WHERE date(r.rental_date) = '2005-06-14';

    SELECT c.first_name, c.last_name,
          time(r.rental_date) rental_time
        FROM customer c
          INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14' ORDER BY c.last_name;


    SELECT c.first_name, c.last_name,
          time(r.rental_date) rental_time
        FROM customer c
          INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14' ORDER BY c.last_name, c.first_name;

    SELECT c.first_name, c.last_name,
          time(r.rental_date) rental_time
        FROM customer c
          INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14' ORDER BY time(r.rental_date) desc;

    SELECT c.first_name, c.last_name,
          time(r.rental_date) rental_time
        FROM customer c
          INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14' ORDER BY 3 desc;

    _____________________________________________________________________________________
    _____________________________________________________________________________________


    SELECT c.email
        FROM customer c
          INNER JOIN rental r
          ON c.customer_id = r.customer_id
        WHERE date(r.rental_date) = '2005-06-14';

    SELECT c.email
        FROM customer c
          INNER JOIN rental r
          ON c.customer_id = r.customer_id
        WHERE date(r.rental_date) <> '2005-06-14';

    DELETE FROM rental
    WHERE year(rental_date) = 2004;

    DELETE FROM rental
    WHERE year(rental_date) <> 2005 AND year(rental_date) <> 2006;

    SELECT customer_id, rental_date
        FROM rental
        WHERE rental_date < '2005-05-25';

    SELECT customer_id, rental_date
        FROM rental
        WHERE rental_date <= '2005-06-16'
          AND rental_date >= '2005-06-14';

    SELECT customer_id, rental_date
        FROM rental
        WHERE rental_date BETWEEN '2005-06-14' AND '2005-06-16';


    SELECT customer_id, rental_date
        FROM rental
        WHERE rental_date BETWEEN '2005-06-16' AND '2005-06-14';

    SELECT customer_id, rental_date
        FROM rental
        WHERE rental_date >= '2005-06-16'
          AND rental_date <= '2005-06-14';


    SELECT customer_id, payment_date, amount
        FROM payment
        WHERE amount BETWEEN 10.0 AND 11.99;                    

    SELECT last_name, first_name
        FROM customer
        WHERE last_name BETWEEN 'FA' AND 'FR'

    SELECT last_name, first_name
        FROM customer
        WHERE last_name BETWEEN 'FA' AND 'FRB';

    SELECT title, rating
        FROM film
        WHERE rating = 'G' OR rating = 'PG';

    SELECT title, rating
    FROM film
    WHERE rating IN ('G','PG');

    SELECT title, rating
        FROM film
        WHERE rating IN (SELECT rating FROM film WHERE title LIKE '%PET%');

    SELECT title, rating
    FROM film
    WHERE rating NOT IN ('PG-13','R', 'NC-17');


    SELECT last_name, first_name
        FROM customer
        WHERE left(last_name, 1) = 'Q';


    SELECT last_name, first_name
        FROM customer
        WHERE last_name LIKE '_A_T%S';

    SELECT last_name, first_name
        FROM customer
        WHERE last_name REGEXP '^[QY]';

    SELECT rental_id, customer_id
        FROM rental
        WHERE return_date IS NULL;

    SELECT rental_id, customer_id
        FROM rental
        WHERE return_date = NULL;

    SELECT rental_id, customer_id, return_date
        FROM rental
        WHERE return_date IS NOT NULL;

    SELECT rental_id, customer_id, return_date
        FROM rental
        WHERE return_date NOT BETWEEN '2005-05-01' AND '2005-09-01';

    SELECT rental_id, customer_id, return_date
        FROM rental
        WHERE return_date IS NULL
          OR return_date NOT BETWEEN '2005-05-01' AND '2005-09-01';

    _____________________________________________________________________________________
    _____________________________________________________________________________________


mysql> use sakila;
Database changed

mysql> 
mysql> desc customer;
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| Field       | Type              | Null | Key | Default           | Extra                                         |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| customer_id | smallint unsigned | NO   | PRI | NULL              | auto_increment                                |
| store_id    | tinyint unsigned  | NO   | MUL | NULL              |                                               |
| first_name  | varchar(45)       | NO   |     | NULL              |                                               |
| last_name   | varchar(45)       | NO   | MUL | NULL              |                                               |
| email       | varchar(50)       | YES  |     | NULL              |                                               |
| address_id  | smallint unsigned | NO   | MUL | NULL              |                                               |
| active      | tinyint(1)        | NO   |     | 1                 |                                               |
| create_date | datetime          | NO   |     | NULL              |                                               |
| last_update | timestamp         | YES  |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
9 rows in set (0.00 sec)

mysql> 
mysql> desc address;
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| Field       | Type              | Null | Key | Default           | Extra                                         |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| address_id  | smallint unsigned | NO   | PRI | NULL              | auto_increment                                |
| address     | varchar(50)       | NO   |     | NULL              |                                               |
| address2    | varchar(50)       | YES  |     | NULL              |                                               |
| district    | varchar(20)       | NO   |     | NULL              |                                               |
| city_id     | smallint unsigned | NO   | MUL | NULL              |                                               |
| postal_code | varchar(10)       | YES  |     | NULL              |                                               |
| phone       | varchar(20)       | NO   |     | NULL              |                                               |
| location    | geometry          | NO   | MUL | NULL              |                                               |
| last_update | timestamp         | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
9 rows in set (0.00 sec)

mysql> 
mysql> 

mysql> desc city;
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| Field       | Type              | Null | Key | Default           | Extra                                         |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
| city_id     | smallint unsigned | NO   | PRI | NULL              | auto_increment                                |
| city        | varchar(50)       | NO   |     | NULL              |                                               |
| country_id  | smallint unsigned | NO   | MUL | NULL              |                                               |
| last_update | timestamp         | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+-------------+-------------------+------+-----+-------------------+-----------------------------------------------+
4 rows in set (0.00 sec)

_____________________________________________________________________________________
_____________________________________________________________________________________


SELECT c.first_name, c.last_name, a.address
    FROM customer c JOIN address a;

SELECT c.first_name, c.last_name, a.address
    FROM customer c JOIN address a
    ON c.address_id = a.address_id;

SELECT c.first_name, c.last_name, a.address FROM customer c INNER JOIN address a
    ON c.address_id = a.address_id;

SELECT c.first_name, c.last_name, a.address
    FROM customer c INNER JOIN address a
    USING (address_id);

SELECT c.first_name, c.last_name, a.address
    FROM customer c, address a
    WHERE c.address_id = a.address_id;

SELECT c.first_name, c.last_name, a.address
    FROM customer c, address a
    WHERE c.address_id = a.address_id
      AND a.postal_code = 52137;

SELECT c.first_name, c.last_name, a.address
    FROM customer c INNER JOIN address a
      ON c.address_id = a.address_id
    WHERE a.postal_code = 52137;

_____________________________________________________________________________________
_____________________________________________________________________________________

desc customer;
desc address;
desc city;

SELECT c.first_name, c.last_name, ct.city
      FROM customer c
      INNER JOIN address a
      ON c.address_id = a.address_id
      INNER JOIN city ct
      ON a.city_id = ct.city_id;


SELECT c.first_name, c.last_name, ct.city
      FROM city ct
      INNER JOIN address a
      ON a.city_id = ct.city_id
      INNER JOIN customer c
      ON c.address_id = a.address_id;

SELECT c.first_name, c.last_name, ct.city
      FROM address a
      INNER JOIN city ct
      ON a.city_id = ct.city_id
      INNER JOIN customer c
      ON c.address_id = a.address_id;

_____________________________________________________________________________________
_____________________________________________________________________________________


SELECT c.first_name, c.last_name, addr.address, addr.city
    FROM customer c
    INNER JOIN
    (SELECT a.address_id, a.address, ct.city
      FROM address a
        INNER JOIN city ct
        ON a.city_id = ct.city_id
      WHERE a.district = 'California'
    ) addr
    ON c.address_id = addr.address_id;


SELECT a.address_id, a.address, ct.city
    FROM address a
      INNER JOIN city ct
      ON a.city_id = ct.city_id
    WHERE a.district = 'California';

_____________________________________________________________________________________
_____________________________________________________________________________________


SELECT f.title
    FROM film f
      INNER JOIN film_actor fa
      ON f.film_id = fa.film_id
      INNER JOIN actor a
      ON fa.actor_id = a.actor_id
    WHERE ((a.first_name = 'CATE' AND a.last_name = 'MCQUEEN')
        OR (a.first_name = 'CUBA' AND a.last_name = 'BIRCH'));



SELECT f.title
     FROM film f
       INNER JOIN film_actor fa1
       ON f.film_id = fa1.film_id
       INNER JOIN actor a1
       ON fa1.actor_id = a1.actor_id
       INNER JOIN film_actor fa2
       ON f.film_id = fa2.film_id
       INNER JOIN actor a2
       ON fa2.actor_id = a2.actor_id
    WHERE (a1.first_name = 'CATE' AND a1.last_name = 'MCQUEEN')
      AND (a2.first_name = 'CUBA' AND a2.last_name = 'BIRCH');

_____________________________________________________________________________________
_____________________________________________________________________________________


SELECT c.first_name, c.last_name
FROM customer c
WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%' 
UNION
SELECT a.first_name, a.last_name
FROM actor a
WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%';


SELECT c.first_name, c.last_name
FROM customer c
WHERE c.first_name LIKE 'D%' AND c.last_name LIKE 'T%' INTERSECT
SELECT a.first_name, a.last_name
FROM actor a
WHERE a.first_name LIKE 'D%' AND a.last_name LIKE 'T%';

_____________________________________________________________________________________
_____________________________________________________________________________________



