_______________________________________________________

DAY 01
_______________________________________________________

	ASSIGNMENT A0
		
		Prepare Development Environment
		Install Ubuntu Desktop/Server 22.04 64 Bit In VirtualBox
		Install Compilers and Editors
		Write/Run HelloWorld.cpp Code

	ASSIGNMENT A1

		Reading Assignment
			The C Programming Langunage, 2nd Edition
				By Brian Kernigham and Dennis Ritchie

			CHAPTER 2 : TYPES, OPERATIONS AND EXPRESSIONS
			CHAPTER 3 : CONTROL FLOWS
			CHAPTER 4 : FUNCTIONS AND PROGRAM STRUCTURE
			CHAPTER 5 : POINTERS AND ARRAYS

_______________________________________________________

DAY 02
_______________________________________________________

	ASSIGNMENT A1

		Reading And Experimentation Assignment
			Reading Till Page 132
				Linux Pocket Guide, Oreilly Publication

		Experiment All The Commands
			Linux Pocket Guide, Oreilly Publication
				Till Page 132

_______________________________________________________

DAY 03
_______________________________________________________

	ASSIGNMENT A1

		Reading And Experimentation Assignment
			Reading Till Page 132
				Linux Pocket Guide, Oreilly Publication

		Experiment All The Commands
			Linux Pocket Guide, Oreilly Publication
				Till Page 132

_______________________________________________________

DAY 04
_______________________________________________________

	ASSIGNMENT A1 : READING ASSIGNMENT  [ MUST MUST ]
		
		1. UML Diagrams Introduction
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://developer.ibm.com/articles/the-class-diagram/
		
		2. Object Oriented Design Notes
			Download : StudyMaterial3.1.zip
		
			├── StudyMaterial3.1
			│ └── 01ObjectOrientedDesignNotes.pdf
		

	ASSIGNMENT A2 : CODING ASSIGNMENT IN C++ [ MUST MUST ]
		
		1. Implement Human Example Using Inheritance
		
		2. Implement Human Example Using Composition

		3. Implement Code Structure In C++ For Following Example
			
			3.1 Airport, FlyingTransport, Helicopter, Airplane, Drones etc.
				Refer Page 9 In 01ObjectOrientedDesignNotes.pdf
			
			3.2 Animal, Cat, FourLegged, OxygenBreather
				Refer Page 1, 2, 4 and 10 In 01ObjectOrientedDesignNotes.pdf
			
			3.3 Improve 3.2 Excerise Design
				Using Polymorphism
				Refer Page 11 In 01ObjectOrientedDesignNotes.pdf


	ASSIGNMENT A3 : READING ASSIGNMENT [ MUST MUST ]
		Download : StudyMaterial3.2.zip

		├── StudyMaterial3.2
		│ ├── 02SoftwareDesignPrinciplesNotes.pdf
		│ ├── C01.FactoryMethod.pdf
		│ └── C02.AbstractFactory.pdf

_______________________________________________________

DAY 05
_______________________________________________________

_______________________________________________________

DAY 06
_______________________________________________________

_______________________________________________________

DAY 07
_______________________________________________________

_______________________________________________________

DAY 08
_______________________________________________________

_______________________________________________________

DAY 09
_______________________________________________________

_______________________________________________________

DAY 10
_______________________________________________________

_______________________________________________________

DAY 11
_______________________________________________________

_______________________________________________________

DAY 12
_______________________________________________________

_______________________________________________________

DAY 13
_______________________________________________________

_______________________________________________________

DAY 14
_______________________________________________________

_______________________________________________________

DAY 15
_______________________________________________________
