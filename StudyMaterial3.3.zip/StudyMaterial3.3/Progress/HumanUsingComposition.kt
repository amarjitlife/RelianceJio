
package something

// In C++ Interfaces Can Be Implemented Using Pure Abstract Class
//	Pure Abstract Class
//		Class With All Function Virtual

// Interface Defines Only 
// 		What It Will Do
//		i.e. It Will Define Communication Contract/Protocol
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Concrete Classes Defines And Implements Interfaces
//		How, When, Where, Which Way etc...
//	fly And saveWorld Implementations
//		How, When, Where, Which Way etc...
class Spiderman: Superpower {
	override fun fly() { 
		println( "Fly Like Spiderman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Spiderman!") 		
	}	
}


class Superman: Superpower {
	override fun fly() { 
		println( "Fly Like Superman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Superman!") 		
	}	
}

class Heman : Superpower {
	override fun fly() { 
		println( "Fly Like Heman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Heman!") 		
	}	
}

class WonderWoman : Superpower  {
	override fun fly() { 
		println( "Fly Like WonderWoman!") 
	}

	override fun saveWorld() {
		println( "Save World Like WonderWoman!") 		
	}	
}

class Ironman {
	fun fly() { 
		println( "Fly Like Ironman!") 
	}

	fun saveWorld() {
		println( "Save World Like Ironman!") 		
	}	
}

// Polymorphism
//		Poly Means Multiple and Morphs Means Forms
//		i.e. Taking Multiple Forms

// Human Is Polymnorphic
// Composition Design Pattern
// Human Is Composed Of Superpower
class Human {
	// In UML Notation This Relationship Is Aggregation Relationship
	var power: Superpower? = null

	fun fly() { 
		power?.fly()
	}

	fun saveWorld() {
		power?.saveWorld()
	}
}

fun main() {
	// var spiderman = Spiderman()
	// spiderman.fly()
	// spiderman.saveWorld()
	println("\nHuman Behaving Like...")
	val human = Human() 

	// Human Is Polymnorphic
	//		Human Is Taking Multiple Forms

	// Configuring Human As Spiderman
	human.power = Spiderman() 

	// Human Start Behaving Like Spiderman
	human.fly()
	human.saveWorld()

	// Configuring Human As Superman
	human.power = Superman()

	// Human Start Behaving Like Superman
	human.fly()
	human.saveWorld()

	human.power = Heman()
	human.fly()
	human.saveWorld()	

	human.power = WonderWoman()
	human.fly()
	human.saveWorld()	

	// human.power = Ironman()
	// human.fly()
	// human.saveWorld()	
}
