______________________________________________________

Linux Commands
______________________________________________________

1. To Change Directory
	Use cd Command

		cd Documents

2. To Make Directory
	mkdir LearnLinux
	cd LearnLinux
	mkdir HindiCinema
	cd HindiCinema

3. To Check Present/Current Working Directory
	pwd

	Change Present/Current Directory To Parent Directoy
		cd ..
	
	pwd
	cd ..
	pwd
	cd ..
	pwd

4. List Content Of Directory
		ls

	To Give Detailed Listing Use Following Command
		ls -l 

	To List All The Files Use Following Command
		Will Show File Names Starting With . Also
			ls -a -l 
			ls -al

______________________________________________________


1. khoj@ubuntu2204:~/Documents/LearnLinux$ tree
.
├── LearnBash
│ ├── Hello.sh
│ └── Something
├── LearnCPP
│ ├── Factorial.cpp
│ ├── Hello.cpp
│ └── Sum.cpp
└── LearnSanskrit
    ├── Alpabats.sans
    ├── LearnEnglish
    │ ├── EnglishAlphabets.en
    │ └── EnglishPoetry.en
    ├── LearnGerman
    ├── LearnHindi
    │ ├── Vakayas.hindi
    │ └── Varanmala.hindi
    ├── Sholakas.sans
    └── Vakyas.sans

6 directories, 12 files

2. Using Sublime Text Write Following Content In Hello.sh

echo "Hello Good Morning!"
echo "Welcome To Training"

3. Experiment Following Commands

 2051  mkdir LearnBash
 2052  clear
 2053  ls
 2054  cd LearnBash/
 2055  ls
 2056  touch Hello.sh
 2057  vim Hello.sh 
 2058  ./Hello.sh
 2059  ls -l
 2060  cat Hello.sh 
 2061  vim Hello.sh 
 2062  ./Hello.sh
 2063  chmod u+x Hello.sh 
 2065  ls -l
 2066  ./Hello.sh 
 2067  touch Something
 2068  ls -l
 2069  ./Something
 2070  chmod 000 Something
 2071  ls -l
 2072  cat Something 
 2073  cat Hello.sh 
 2074  chmod u+r Something 
 2075  cat Something 
 2076  ls -l
 2077  tree
 2078  cd ..
 2079  tree
 2080  cat LearnBash/Hello.sh 
 2081  history

2090  touch someFood
 2091  ls
 2092  ls -l
 2093  chmod 777 someFood 
 2094  ls -l
 2095  touch bankAccount
 2096  ls -l
 2097  chmod 700 bankAccount 
 2098  ls -l
 2099  touch someBike
 2100  ls -l
 2101  chmod 760 bankAccount 
 2102  ls -l
 2103  chmod 700 bankAccount 
 2104  chmod 760 someBike
 2105  ls -l
 2106  chmod 664 Something 
 2107  ls -l
 2108  chmod 640 Something 
 2109  ls -l
 2110  chmod 000 Something 
 2111  ls -l
 2112  chmod 640 Something 
 2113  clear
 2114  ls
 2115  umask
 2116  touch someNewFile
 2117  ls -l
 2118  umask 0022
 2119  umask
 2120  touch someNewFileAgain
 2121  ls -l
 2122  cd ..
 2123  ls -l
 2124  umask 0002
 2125  umask

___________________________________________________________


 2035  cd LearnCPP/
 2036  ls
 2037  touch Hello.cc
 2038  touch Sum.cc
 2039  ls 
 2040  ls =-l
 2041  ls -l
 2042  ls -l *.cpp
 2043  ls -l *.cc
 2044  ls -l H*
 2045  env
 2046  export DING_DONG="Ding Dong Ding Dong"
 2047  env
 2048  env | grep DING
 2049  env
 2050  printenv
 2051  echo $PATH
 2052  clear
 2053  ls
 2054  cd ..
 2055  clear
 2056  ls
 2057  cd LearnBash/
 2058  ls
 2059  ./Hello.sh 
 2060  touch GoodMorning
 2061  vim GoodMorning 
 2062  vim GoodEvening
 2063  chmod u+x GoodMorning GoodEvening 
 2064  ls -l
 2065  ./GoodMorning 
 2066  ./GoodEvening 
 2067  ./Hello.sh 
 2068  GoodMorning
 2069  GoodEvening
 2070  ls
 2071  pwd
 2072  echo $PATH
 2073  export PATH=$PATH:/home/khoj/Documents/LearnLinux/LearnBash
 2074  echo $PATH
 2075  GoodEvening
 2076  GoodMorning
 2077  Hello.sh 
 2078  history


___________________________________________________________

2108  vim loveLetter.txt
 2109  cat loveLetter.txt 
 2110  cat < loveLetter.txt 
 2111  cat < loveLetter.txt  someFile.txt 
 2112  cat < loveLetter.txt 
 2113  cat < loveLetter.txt < someFile.txt 
 2114  cat < loveLetter.txt 
 2115  ls -l
 2116  cd ..
 2117  clear
 2118  ls
 2119  cd LearnBash/
 2120  clear
 2121  ls
 2122  ls -l
 2123  ls -l > lsOutputFile.txt
 2124  ls
 2125  vim lsOutputFile.txt 
 2126  cat < Hello.sh 
 2127  cat Hello.sh 
 2128  cat
 2129  ls
 2130  cat Hello.sh 
 2131  cat Hello.sh > HelloCopy
 2132  cat HelloCopy 
 2133  cat Hello.sh 
 2134  cat Hello.sh GoodMorning GoodEvening > HelloCopy
 2135  cat HelloCopy 
 2136* cat Hello.sh GoodMorning GoodEvening >
 2137  ls
 2138  vim Something 
 2139  cat Something 
 2140  cat Something > HelloCopy 
 2141  cat HelloCopy 
 2142  cat Hello.sh GoodMorning GoodEvening > HelloCopy
 2143  cat HelloCopy 
 2144  cat Something >> HelloCopy 
 2145  cat HelloCopy 
 2146  ls -l
 2147  ls -l | grep *.txt
 2148  ls -l | wc
 2149  ls -l
 2150  ls -l | sort
 2151  touch something.txt
 2152  touch somethingAgain.txt
 2153  ls -l | grep *.txt
 2154  ls -l
 2155  ls -l | grep *.txt
 2156  ls -l | grep .txt
 2157  ls -l | grep .txt | sort
 2159  ls -l
 2160  ls -a
 2161  ls -l ; ls -a
 2162  history

___________________________________________________________

2139  cd LearnCPP/
 2140  ls
 2141  vim Factorial.cpp 
 2142  cat Factorial.cpp 
 2143  cp Factorial.cpp FactorialCopy.cpp 
 2144  ls
 2145  cat FactorialCopy.cpp 
 2146  cat Factorial.cpp 
 2147  cd ..
 2148  clear
 2149  ls
 2150  cp LearnCPP LearnCPPCopy
 2151  cp -r LearnCPP LearnCPPCopy
 2152  ls
 2153  tree
 2154  clera
 2155  ls
 2156  clear
 2157  ls
 2158  cd LearnCPP
 2159  ls
 2160  mv FactorialCopy.cpp FactorialDuplicate.cpp
 2161  clear
 2162  ls
 2163  cd ..
 2164  clear
 2165  ls
 2166  mkdir LearnLatin
 2167  ls
 2168  mv LearnLatin LearnSanskrit/
 2169  tree
 2170  clear
 2171  ls
 2172  rmdir LearnCPPCopy/
 2173  cd LearnCPPCopy/
 2174  ls
 2175  rm *
 2176  ls
 2177  cd ..
 2178  ls
 2179  rmdir LearnCPPCopy/
 2180  ls
 2181  clear
 2182  ls
 2183  cp -r LearnCPP LearnCPPCopy
 2184  clear
 2185  ls
 2186  rm LearnCPPCopy
 2187  rm -r LearnCPPCopy
 2188  ls
 2189  tree
 2190  clear
 2191  ls
 2192  man ln
 2193  ln -s LearnSanskrit/LearnHindi/Vakayas.hindi hindiVakya
 2194  ls
 2195  ls -l
 2196  cd LearnSanskrit/
 2197  cd LearnHindi/
 2198  vim Vakayas.hindi 
 2199  cat Vakayas.hindi 
 2200  cd ../..
 2201  clear
 2202  ls
 2203  ls -l
 2204  vim hindiVakya 
 2205  history

___________________________________________________________

 2204  vim hindiVakya 
 2205  history
 2206  ls 
 2207  man ls
 2208  ls
 2209  stat hindiVakya 
 2210  vim hindiVakya 
 2211  stat hindiVakya 
 2212  cd LearnSanskrit/
 2213  cd LearnHindi/
 2214  ls
 2215  cd ..
 2216  clear
 2217  ls
 2218  cd ..
 2219  clear
 2220  ls
 2221  cd LearnBash/
 2222  clear
 2223  ls
 2224  cat Hello.sh 
 2225  stat Hello.sh 
 2226  vim Hello.sh 
 2227  stat Hello.sh 
 2228  wc Hello.sh 
 2229  vim Hello.sh 
 2230  du 
 2231  cd ..
 2232  du
 2233  du -h
 2234  history


___________________________________________________________

 2236  find . -type f
 2237  find . -type f -name *.cpp
 2238  find . -type f -name *.hindi
 2239  find . -type f -name s*
 2240  find . -type d
 2241  find . -type l
 2242  ls -l
 2243  find . -user root
 2244  find . -size 10
 2245  whereis ls
 2248  ls
 2249  cd LearnCPP/
 2250  ls
 2251  cd ../LearnBash/
 2252  clear
 2253  ls
 2254  grep echo Hello.sh 
 2255  cp Hello.sh Something 
 2256  clear
 2257  ls
 2258  vim Something 
 2259  grep echo Something 
 2260  grep Ting Something 
 2261  grep Ting Something  | nl
 2262  grep Tong Something 
 2263  grep Ding Something 
 2264  find . -type f
 2265  find . -type f | grep echo
 2266  find . -type f 
 2267  history

___________________________________________________________

 2271  free
 2272  free -h
 2274  host
 2275  host -a
 2276  whois redhat.com
 2277  sudo apt install whois
 2278  whois redhat.com
 2279  ping www.google.com
 2280  history
 2281  ping www.google.com
 2282  whois google.com
 2283  free
 2284  free -h
 2285  top
 2286  ps
 2287  ps -eaf 
 2288  ps -eaf | grep chrome
 2289  ps -eaf | grep terminal
 2290  top
 2291  ping www.google.com
 2295  traceroute www.google.com
 2296  sudo apt install traceroute
 2297  traceroute www.google.com
 2298  ping www.google.com
 2299  traceroute www.google.com
 2300  history

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________

___________________________________________________________


