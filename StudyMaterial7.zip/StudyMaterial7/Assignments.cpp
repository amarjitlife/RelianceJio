_______________________________________________________

DAY 01
_______________________________________________________

	ASSIGNMENT A0
		
		Prepare Development Environment
		Install Ubuntu Desktop/Server 22.04 64 Bit In VirtualBox
		Install Compilers and Editors
		Write/Run HelloWorld.cpp Code

	ASSIGNMENT A1

		Reading Assignment
			The C Programming Langunage, 2nd Edition
				By Brian Kernigham and Dennis Ritchie

			CHAPTER 2 : TYPES, OPERATIONS AND EXPRESSIONS
			CHAPTER 3 : CONTROL FLOWS
			CHAPTER 4 : FUNCTIONS AND PROGRAM STRUCTURE
			CHAPTER 5 : POINTERS AND ARRAYS

_______________________________________________________

DAY 02
_______________________________________________________

	ASSIGNMENT A1

		Reading And Experimentation Assignment
			Reading Till Page 132
				Linux Pocket Guide, Oreilly Publication

		Experiment All The Commands
			Linux Pocket Guide, Oreilly Publication
				Till Page 132

_______________________________________________________

DAY 03
_______________________________________________________

	ASSIGNMENT A1

		Reading And Experimentation Assignment
			Reading Till Page 132
				Linux Pocket Guide, Oreilly Publication

		Experiment All The Commands
			Linux Pocket Guide, Oreilly Publication
				Till Page 132

_______________________________________________________

DAY 04
_______________________________________________________


	ASSIGNMENT A1 : READING ASSIGNMENT  [ MUST MUST ]
		
		1. UML Diagrams Introduction
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://developer.ibm.com/articles/the-class-diagram/
		
		2. Object Oriented Design Notes
			Download : StudyMaterial3.1.zip
		
			├── StudyMaterial3.1
			│ └── 01ObjectOrientedDesignNotes.pdf
		

	ASSIGNMENT A2 : CODING ASSIGNMENT IN C++ [ MUST MUST ]
		
		1. Implement Human Example Using Inheritance
		
		2. Implement Human Example Using Composition

		3. Implement Code Structure In C++ For Following Example
			
			3.1 Airport, FlyingTransport, Helicopter, Airplane, Drones etc.
				Refer Page 9 In 01ObjectOrientedDesignNotes.pdf
			
			3.2 Animal, Cat, FourLegged, OxygenBreather
				Refer Page 1, 2, 4 and 10 In 01ObjectOrientedDesignNotes.pdf
			
			3.3 Improve 3.2 Excerise Design
				Using Polymorphism
				Refer Page 11 In 01ObjectOrientedDesignNotes.pdf


	ASSIGNMENT A3 : READING ASSIGNMENT [ MUST MUST ]
		Download : StudyMaterial3.2.zip

		├── StudyMaterial3.2
		│ ├── 02SoftwareDesignPrinciplesNotes.pdf

		│ ├── C01.FactoryMethod.pdf
		│ └── C02.AbstractFactory.pdf

_______________________________________________________

DAY 05 : FULL 09 DAYS ASSIGNMENTS
_______________________________________________________


	ASSIGNMENT A1 : READING AND CODING PRACTICE ASSIGNMENTS  [ MUST MUST ]
		
		1. Thinking In C++, Volume I, 2nd Edition, Bruce Eckel
			Dowload Link : http://www.micc.unifi.it/bertini/download/programmazione/TICPP-2nd-ed-Vol-one-printed.pdf
			Read All 16 Chapters and Practice All Chapter Code Examples


	ASSIGNMENT A2 : CODING AND DESIGN REASONING ASSIGNMENTS IN C++ [ MUST MUST ]
		
		3. Implement Code Structure In C++ For Following Example
			
			3.1 Airport, FlyingTransport, Helicopter, Airplane, Drones etc.
				Refer Page 9 In 01ObjectOrientedDesignNotes.pdf
			
			3.2 Animal, Cat, FourLegged, OxygenBreather
				Refer Page 1, 2, 4 and 10 In 01ObjectOrientedDesignNotes.pdf
			
			3.3 Improve 3.2 Excerise Design
				Using Polymorphism
				Refer Page 11 In 01ObjectOrientedDesignNotes.pdf

		4. Implement Code Structure In C++ For Following Example
			
			4.1 Implement Order and TaxCalculator Class 
				Reference Page 38 and Page 39

			4.2 Implement Cat, Sausage, Food etc.. Classes/Interface 
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 40

			4.3 Implement Company, Designer, Programmer, Tester etc... Classes/Interface 
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 41 and 42

			4.4 Implement Company, GameDevCompany, OutsourcingCompany, Designer, Programmer, Tester, Employe etc... Classes/Interface 
				Reference Page 43

			4.5 Implement Transport Example Classes/Interfaces 
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 46 and 47

			4.6 Implement Order Example Classes/Interfaces 
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 52 and 53

			4.7 Implement Interfaces Example
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 62 and 63

			4.8 Implement Database Example
				Code Both Design I and Design II and Compare Which One Is Better?
				Reference Page 65 and 66


	ASSIGNMENT A3 : READING ASSIGNMENT [ MUST MUST ]
		Download : StudyMaterial3.2.zip

		├── StudyMaterial3.2
		│ ├── C01.FactoryMethod.pdf
		│ └── C02.AbstractFactory.pdf


	ASSIGNMENT A4 : CODING AND DESIGN REASONING ASSIGNMENTS IN C++ [ MUST MUST ]

		Implement Design Patterns Code Structure In C++ For Following Example
			
		1. Factory Method Design Pattern

			1. Implement Logistics and Transport Example In C++
				Reference: C01.FactoryMethod.pdf

			2. Implement Dialog and Button Example In C++
				Reference: In C01.FactoryMethod.pdf ( Pseudo Code Given )

		2. Abstract Factory Design Pattern

			1. Implement Furniture Factory Example In C++
				Reference: C02.AbstractFactory.pdf

			2. Implement GUIFactory Example In C++
				Reference: C02.AbstractFactory.pdf ( Pseudo Code Given )

	ASSIGNMENT A5 : READING ASSIGNMENT [ MUST MUST ]

		Download : StudyMaterial4.1.zip

		├── StudyMaterial4.1
			├── C03.Builder.pdf
			├── C04.Prototype.pdf
			└── C05.Singleton.pdf

	ASSIGNMENT A6 : CODING AND DESIGN REASONING ASSIGNMENTS IN C++ [ MUST MUST ]

		Implement Design Patterns Code Structure In C++ For Following Example

		3. Builder Design Pattern

			1. Implement Car Builder Example In C++
				Reference: C03.Builder.pdf ( Pseudo Code Given )

		4. Prototype Design Pattern

			1. Implement Prototype Registery and Button Example In C++
				Reference: C04.Prototype.pdf

			2. Implement Shape, Rectangle, Cirlce Example In C++
				Reference: C04.Prototype.pdf ( Pseudo Code Given )

		5. Singleton Design Pattern

			1.  Implement Database Signleton Example In C++
				Reference: C05.Singleton.pdf ( Pseudo Code Given )

			2.  Implement India Class As Singleton Example In C++
				Reference: C05.Singleton.pdf				


	ASSIGNMENT A7 : READING, CODING AND DESIGN PRACTICE ASSIGNMENTS  [ MUST MUST ]
		
		1. Practical Object Oriented Design In Ruby By Sandy Metz
			Read First 08 Chaptes And Code Examples In C++


	FOLLOW FOLLOWING ORDER TO COMPLETE ASSIGNMENTS
		ASSIGNMENT A1 
		ASSIGNMENT A2 To A6 [ Implement In Parallel To A1 ]
		ASSIGNMENT A7 [ Start After Completing A1 to A6 ]

	REVISE AND PRACTICE LINUX COMMANDS

_______________________________________________________

DAY 06
_______________________________________________________

	ASSIGNMENT D06.A1 : IMPLEMENT FOLLOWING PROBLEM SOLUTION

		REFERENCE: USING CONCEPTUAL C++ CODE [ MUST MUST ]

			├── StudyMaterial5
			│ ├── C01.FactoryMethodPattern.cpp			
			│ ├── C02.AbstractFactoryPattern.cpp
			│ ├── C03.BuilderPattern.cpp
			│ ├── C04.PrototypePattern.cpp
			│ ├── C05.SingletonPattern.cpp
			│ └── C05.SingletonPatternThreadSafe.cpp

		REFERENCE: USING NOTES

			├── C01.FactoryMethod.pdf
			|── C02.AbstractFactory.pdf
			|── C03.Builder.pdf
			├── C04.Prototype.pdf
			└── C05.Singleton.pdf

		R1. Reason UML Diagrams and Corresponding C++ Implementation
		R2. Reason Pseudo Code and Corresponding C++ Implementation
		R3. Find Missing Details In UML and Pseudo Code
				Which Required To Be Implemented
		R4. Purpose Of Each Design Pattern

		Revise C01 To C05 And Answer Above Questions R1 to R3 
		For The Following Assignments

		1. Factory Method Design Pattern

			├── StudyMaterial5
			│ ├── C01.FactoryMethodPattern.cpp			

			Refer Above Code Example To Implement 1.1 and 1.2 Excerise

			1. Implement Logistics and Transport Example In C++
				Reference: C01.FactoryMethod.pdf

			2. Implement Dialog and Button Example In C++
				Reference: In C01.FactoryMethod.pdf ( Pseudo Code Given )

		2. Abstract Factory Design Pattern

			1. Implement Furniture Factory Example In C++
				Reference: C02.AbstractFactory.pdf

			2. Implement GUIFactory Example In C++
				Reference: C02.AbstractFactory.pdf ( Pseudo Code Given )

		3. Builder Design Pattern

			1. Implement Car Builder Example In C++
				Reference: C03.Builder.pdf ( Pseudo Code Given )

		4. Prototype Design Pattern

			1. Implement Prototype Registery and Button Example In C++
				Reference: C04.Prototype.pdf

			2. Implement Shape, Rectangle, Cirlce Example In C++
				Reference: C04.Prototype.pdf ( Pseudo Code Given )

		5. Singleton Design Pattern

			1.  Implement Database Signleton Example In C++
				Reference: C05.Singleton.pdf ( Pseudo Code Given )

			2.  Implement India Class As Singleton Example In C++
				Reference: C05.Singleton.pdf				


	ASSIGNMENT D06.A2 : READING ASSIGNMENT 

		├── StudyMaterial5.1
		│ ├── SelectedDesignPatternsNotes
		│ │ ├── B02.CommandPattern.pdf
		│ │ ├── B03.IteratorPattern.pdf
		│ │ ├── B07.StatePattern.pdf
		│ │ ├── B09.TemplateMethodPattern.pdf
		│ │ ├── S01.AdapterPattern.pdf
		│ │ ├── S03.CompositePattern.pdf
		│ │ └── S07.ProxyPattern.pdf

		├── StudyMaterial5.1
		│ └── SelectedPatterns
		│     ├── B02.CommandPattern.cpp
		│     ├── B03.IteratorPattern.cpp
		│     ├── B07.StatePattern.cpp
		│     ├── B09.TemplateMethodPattern.cpp
		│     ├── S01.AdapterPatternMultipleInheritance.cpp
		│     ├── S01.AdapterPatternNormal.cpp
		│     ├── S03.CompositePattern.cpp
		│     └── S07.ProxyPattern.cpp

_______________________________________________________

DAY 07
_______________________________________________________


ASSIGNMENT D07.A1 :COMPETE FOLLOWING ASSIGNMENT WHOEVER HAVENOT DONE

	4. Prototype Design Pattern

		4.1. Implement Prototype Registery and Button Example In C++
			Reference: C04.Prototype.pdf

		4.2. Implement Shape, Rectangle, Cirlce Example In C++
			Reference: C04.Prototype.pdf ( Pseudo Code Given )

	5. Singleton Design Pattern

		5.1.  Implement Database Signleton Example In C++
			Reference: C05.Singleton.pdf ( Pseudo Code Given )

		5.2.  Implement India Class As Singleton Example In C++
			Reference: C05.Singleton.pdf				


ASSIGNMENT D07.A2 : READING ASSIGNMENT 

	├── StudyMaterial5.1
	│ ├── SelectedDesignPatternsNotes
	│ │ ├── B02.CommandPattern.pdf		
	│ │ ├── B03.IteratorPattern.pdf
	│ │ ├── B07.StatePattern.pdf
	│ │ ├── B09.TemplateMethodPattern.pdf
	│ │ ├── S01.AdapterPattern.pdf


ASSIGNMENT D07.A3 : CODING ASSIGNMENTS

	COMMAND PATTERN

		├── B02.CommandPattern.cpp

		Reference: Above Command Pattern Structure Code
		B02.CommandPattern.cpp			
		
		B02.1. Implement Command Pattern i.e. Editor, Application, CommandHistory
		 and Various Commands CopyCommand, CutCommand etc..
		 [ Pseudo Code Given ]
			 
			Objectives : helps to track the history  of executed operations 
			and makes it possible to revert an operation if needed.

		B02.2. Implement Command Pattern To Simulate Real World Scenario
			Of Customer, Waiter and Chef, Request, Order, Food


	ITERATOR PATTERN
		
		├── B03.IteratorPattern.cpp

		Reference:  Above Command Pattern Structure Code
		B03.IteratorPattern.cpp
		
		B03.1. Implement TreeCollections with DepthFirstIterator, BreathFirstIterator

		B03.2. LinkList with FrontToEndIterator, EndToFrontIterator

		B03.3. Implement Application, SocialNetwork, Facebook, FacebookIterator,
		ProfileIterator etc. [ Pseudo Code Given ]


	STATE PATTERN

		├── B07.StatePattern.cpp

		Reference: Above Command Pattern Structure Code
		B07.StatePattern.cpp		

		B07.1. Implement State Pattern lets the same controls of 
				the media player behave differently, depending on 
				the current playback state.

				Player, State, ReadyState, PlayingState, LockedState etc.
				[ Pseudo Code Given ]

	TEMPLATE METHOD PATTERN
		
		├── B09.TemplateMethodPattern.cpp

		Reference: Above Command Pattern Structure Code
		B09.TemplateMethodPattern.cpp	

		B09.1. Implement The Template Method Pattern 
				provides a “skeleton” for various branches of artificial
				intelligence in a simple strategy video game.

				GameAI, OrcsAI, MonstersAI etc...
				[ Pseudo Code Given ]


	ADAPTER PATTERN

		├── S01.AdapterPatternNormal.cpp
		
		Reference: Above Command Pattern Structure Code
		S01.AdapterPatternNormal.cpp
		
		S01.1. Implement Adapter Pattern To adapt between 
				Square Pegs and Round Holes.
				[ Pseudo Code Given ]

_______________________________________________________

DAY 08
_______________________________________________________


ASSIGNMENT D08.A1 : REVISION ASSIGNMENT 

	Write Intent/Purpose Of Following Design Patterns 
		and Draw Structure Diagram
		and Explain To Each Other

		├── C01.FactoryMethod.pdf
		├── C02.AbstractFactory.pdf
		├── C03.Builder.pdf
		├── C04.Prototype.pdf
		├── C05.Singleton.pdf
		├── B02.CommandPattern.pdf		
		├── B03.IteratorPattern.pdf
		├── B07.StatePattern.pdf
		├── B09.TemplateMethodPattern.pdf
		├── S01.AdapterPattern.pdf
		├── S03.CompositePattern.pdf
		└── S07.ProxyPattern.pdf

	There Will Be Viva Followed By It!

ASSIGNMENT D08.A2 : READING ASSIGNMENT 

	REFERENCE NOTES

		├── C01.FactoryMethod.pdf
		├── C02.AbstractFactory.pdf
		├── C03.Builder.pdf
		├── C04.Prototype.pdf
		├── C05.Singleton.pdf
		├── B02.CommandPattern.pdf		
		├── B03.IteratorPattern.pdf
		├── B07.StatePattern.pdf
		├── B09.TemplateMethodPattern.pdf
		├── S01.AdapterPattern.pdf
		├── S03.CompositePattern.pdf
		└── S07.ProxyPattern.pdf


ASSIGNMENT D08.A3 : CODING ASSIGNMENTS

	ITERATOR PATTERN
		
		├── B03.IteratorPattern.cpp

		Reference:  Above Command Pattern Structure Code
		B03.IteratorPattern.cpp
		
		B03.1. Implement TreeCollections with DepthFirstIterator, BreathFirstIterator

		B03.2. LinkList with FrontToEndIterator, EndToFrontIterator

		B03.3. Implement Application, SocialNetwork, Facebook, FacebookIterator,
		ProfileIterator etc. [ Pseudo Code Given ]

	COMPOSITE PATTERN

		├── S03.CompositePattern.pdf
		
		S03.1. Implement The Composite Pattern to stacking of 
			geometric shapes in a ImageEditor, Graphics, 
			CompoundGraphics, Dot, Circle, Square, Rectangle, Line etc.
			[ Pseudo Code Given ]

	PROXY PATTERN

		├── S07.ProxyPattern.pdf

		S07.1. Implement The Proxy Pattern In YouTubeManager, ThirdPartyYouTubeLib
		CachedYouTubeLib, ThirdPartyYouTubeClass etc.
			[ Pseudo Code Given ]

	PRACTICE GIT COMMANDS

_______________________________________________________

DAY 09
_______________________________________________________

_______________________________________________________

DAY 10
_______________________________________________________

_______________________________________________________

DAY 11
_______________________________________________________

_______________________________________________________

DAY 12
_______________________________________________________

_______________________________________________________

DAY 13
_______________________________________________________

_______________________________________________________

DAY 14
_______________________________________________________

_______________________________________________________

DAY 15
_______________________________________________________
