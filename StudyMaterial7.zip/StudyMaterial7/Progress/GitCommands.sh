       cd Documents
 2079  pwd
 2080  git clone https://github.com/amarjitlife/LearnGit.git
 2082  git --version
 2083  ls
 2084  cd LearnGit/
 2086  ls
 2087  ls -l
 2088  cat README.md 
 2095  git status
 2096  git config --list
 2097  git log
 2101  touch factorial.c
 2102  ls -l
 2103  vim factorial.c 
 2104  git status
 2105  git add factorial.c 
 2106  git status
 2107  git commit
 2108  git config --local user.email "amarjitlife@gmail.com"
 2109  git config --local user.name "Amarjit Singh"
 2110  git config --list
 2113  git config --local core.editor "vim"
 2114  git config --list
 2116  vim --version
 2121  git status
 2115  git commit
 2118  git log
 2128  vim factorial.c 
 2129  cat factorial.c 
 2132  git status
 2134  ls -l
 2135  git status
 2136  git diff
 2137  git add factorial.c 
 2138  git status
 2139  git diff
 2140  git diff --cached
 2141  git status
 2142  git diff --cached
 2143  git commit
 2144  git status
 2145  git log

 