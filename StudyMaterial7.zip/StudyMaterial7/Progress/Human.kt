
package something


interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman: Superpower {
	override fun fly() { 
		println( "Fly Like Spiderman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Spiderman!") 		
	}	
}

class Superman: Superpower {
	override fun fly() { 
		println( "Fly Like Superman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Superman!") 		
	}	
}

class Heman : Superpower {
	override fun fly() { 
		println( "Fly Like Superman!") 
	}

	override fun saveWorld() {
		println( "Save World Like Superman!") 		
	}	
}


// Composition Design Pattern
// Human Is Composed Of Superpower
class Human {
	// In UML Notation This Is Aggregation Relationship
	var power: Superpower? = null

	fun fly() { 
		power?.fly()
	}

	fun saveWorld() {
		power?.saveWorld()
	}
}

fun main() {
	// var spiderman = Spiderman()
	// spiderman.fly()
	// spiderman.saveWorld()

	println("\nHuman Behaving Like...")
	val human = Human() 

	human.power = Spiderman()
	human.fly()
	human.saveWorld()

	human.power = Superman()
	human.fly()
	human.saveWorld()

	human.power = Heman()
	human.fly()
	human.saveWorld()	
}

// Human Behaving Like...
// Fly Like Spiderman!
// Save World Like Spiderman!

